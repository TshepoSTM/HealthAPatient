export const url_key = 'http://batcave.healtha.co.za/Administration/';
export const pic_url = 'https://batcave.healtha.co.za/Uploads/';
export const logo_url = 'https://batcave.healtha.co.za/uploads/';
export const auth_key_fcm =  'AAAA7rCR-Ec:APA91bFIqxn6vBBlXNJ0HXHRCJqw9J05xz4weTbKPgMPdcMNGk-D53YpC350E1PkOlm5C6s-KD3aq1AAJdSIHfQ66ojbBl4Jjuto_FjOzYp1T1Rvy6UiAyr4dH_aKIKO4BzAhceLLKjP';
