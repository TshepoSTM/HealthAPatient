import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCBCXTgu4GIanyQhSSLrNwNXvO-THvTQ1k",
  authDomain: "healthachat.firebaseapp.com",
  projectId: "healthachat",
  storageBucket: "healthachat.appspot.com",
  messagingSenderId: "1025164572743",
  appId: "1:1025164572743:web:711a785547f5235e02d962",
  measurementId: "G-PRJVMLBVZD",
};

// Initialize Firebase
//const app = initializeApp(firebaseConfig);

let app;
if (firebase.apps.length === 0) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app();
}
const db = app.firestore();
const auth = firebase.auth();
export { db, auth };
