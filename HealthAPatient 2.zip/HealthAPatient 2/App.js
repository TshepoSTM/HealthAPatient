import "react-native-gesture-handler";
import React from "react";
import { StyleSheet, Text, View, AppRegistry } from "react-native";
import {
  NavigationContainer,
  withNavigation,
  useNavigation,
  createNavigationContainerRef,
} from "@react-navigation/native";
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { url_key } from "./config/url_key";
import { AuthContext } from "./Screens/Context";
import FlashMessage, {
  showMessage,
  hideMessage,
} from "react-native-flash-message";

import RootStackScreen from "./StackScreens/RootStackScreen";
import StarterStackScreen from "./StackScreens/StarterStackScreen"; /**/

export const navigationRef = createNavigationContainerRef();

export default function App() {
  const [isLoading, setIsloading] = React.useState(false);

  const initialLoginState = {
    isLoading: null,
    email: null,
    userToken: null,
    userId: null,
  };

  const loginReducer = (prevState, action) => {
    switch (action.type) {
      case "RETRIEVE_TOKEN":
        return {
          ...prevState,
          userToken: action.token,
          isLoading: false,
        };
      case "LOGIN":
        return {
          ...prevState,
          isLoading: false,
          email: action.id,
          userToken: action.token,
        };
      case "LOGOUT":
        return {
          ...prevState,
          email: action.id,
          userToken: null,
          isLoading: false,
        };
      case "REGISTER":
        return {
          ...prevState,
          isLoading: false,
          email: null,
          userToken: null,
        };
    }
  };

  const [loginState, dispatch] = React.useReducer(
    loginReducer,
    initialLoginState
  );

  const authContext = React.useMemo(
    () => ({
      signIn: async (email, password) => {
        let userToken;
        userToken = null;

        var param = { email: email, pass: password, role: 2 };

        var data = { name: "login", param: param };

        axios({
          url: url_key + "login",
          method: "POST",
          data: data,
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        })
          .then(
            (response) => {
              console.log(response.data);
              if (response.data.error) {
                //console.warn(response.data.error.message);
                showMessage({
                  message: response.data.error.message,
                  type: "warning",
                });
                userToken = null;
              } else {
                userToken = response.data.Token;
                AsyncStorage.setItem("userToken", JSON.stringify(userToken));
                //console.log('user Token',userToken);
                dispatch({ type: "LOGIN", id: email, token: userToken });
              }
            },
            (error) => {
              console.log(error);
            }
          )
          .catch((error) => {
            console.log(error);
          });

        //console.log('user token',userToken);
        //dispatch({type:'LOGIN',id:email,token:userToken});
      },
      signOut: async () => {
        /*setUserToken(null);
      setIsloading(false);*/
        try {
          userToken = await AsyncStorage.removeItem("userToken");
        } catch (error) {
          console.log(error);
        }
        dispatch({ type: "LOGOUT" });
      },
      SignUp: () => {
        /*setUserToken('1');
      setIsloading(false);*/
      },
      FBSignIn: async (userToken, name) => {
        console.log(userToken);
        /*if(userToken == undefined)
      {
        console.log('no token')
      }else{
        console.log(userToken)
        AsyncStorage.setItem('userToken',userToken)
              //console.log('user Token',userToken);
        dispatch({type:'LOGIN',id:name,token:userToken});
      }*/
      },
      googleSignIn: async (userToken, user) => {
        console.log(user);
        var param = { email: user.email, role: 2 };

        var data = { name: "googleSignin", param: param };

        axios({
          url: url_key + "googleSignin",
          method: "POST",
          data: data,
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        })
          .then(
            (response) => {
              console.log(response.data.length);

              if (response.data.length == 0) {
                navigationRef.navigate("SignUp", {
                  email: user.email,
                  firstname: user.givenName,
                  surname: user.familyName,
                  picName: user.photoUrl,
                });
              } else {
                console.log(response.data);
                userToken = response.data.Token;
                AsyncStorage.setItem("userToken", JSON.stringify(userToken));
                console.log("user Token", userToken);
                dispatch({ type: "LOGIN", id: param.email, token: userToken });
              }
            },
            (error) => {
              console.log(error);
            }
          )
          .catch((error) => {
            console.log(error);
          });
      },
    }),
    []
  );

  React.useEffect(() => {
    setTimeout(async () => {
      let userToken;
      let userId;
      userToken = null;

      try {
        userToken = await AsyncStorage.getItem("userToken");
      } catch (error) {
        console.log(error);
      }
      dispatch({ type: "RETRIEVE_TOKEN", token: userToken });
      //dispatch({type:'REGISTER',id:email,token:userToken});
    }, 1000);
  }, []);

  if (loginState.isLoading) {
    <View>
      <ActivityIndicator
        size="Large"
        style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
      />
    </View>;
  }

  return (
    <AuthContext.Provider value={authContext}>
      <NavigationContainer ref={navigationRef}>
        {loginState.userToken !== null ? (
          <RootStackScreen />
        ) : (
          <StarterStackScreen />
        )}
      </NavigationContainer>
    </AuthContext.Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
