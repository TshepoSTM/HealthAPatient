import React, {
  useEffect,
  useCallback,
  useState,
  useLayoutEffect,
} from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import { GiftedChat, Send, Bubble } from "react-native-gifted-chat";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { db, auth } from "../config/firebase";
import axios from "axios";
import { url_key, myApiKey, auth_key_fcm } from "../config/url_key";

const ChatScreen = ({ route, navigation }) => {
  const [messages, setMessages] = useState([]);
  const [userToken, setUserToken] = React.useState(null);
  const [user_id, setUser_id] = React.useState(route.params.user_id);
  const [hcp_id, setHcp_id] = React.useState(route.params.hcp_id);
  const [consult_id, setConsult_id] = React.useState(route.params.con_id);
  const [expoPushToken, setExpoPushToken] = React.useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getToken();
    //console.log(route.params);

    db.collection("chats")
      .where("consult_id", "==", consult_id)
      .onSnapshot((querySnapshot) => {
        const threads = querySnapshot.docs.map((documentSnapshot) => {
          return {
            _id: documentSnapshot.id,
            ...documentSnapshot.data(),
          };
        });
        setLoading(false);
        //console.log(threads);

        threads.sort(function (a, b) {
          var c = new Date(a.createdAt);
          var d = new Date(b.createdAt);
          return d - c;
        });
        setMessages(threads);
      });
  }, []);

  const getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      setUserToken(userToken);
      //console.log('user token',userToken);
      getHCPpushToken(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  const getHCPpushToken = (userToken) => {
    var param = { hcp_id: route.params.hcp_id };
    var data = {
      name: "getHCPpushToken",
      param: param,
      token: JSON.parse(userToken),
    };

    axios({
      url: url_key + "getHCPpushToken",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          console.log(response.data.expoPushToken);
          setExpoPushToken(response.data.expoPushToken);
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  };

  function renderBubble(props) {
    return (
      <Bubble
        {...props}
        wrapperStyle={{
          right: {
            // Here is the color change
            backgroundColor: "#6646ee",
          },
        }}
        textStyle={{
          right: {
            color: "#fff",
          },
        }}
      />
    );
  }
  function renderSend(props) {
    return (
      <Send {...props}>
        <View style={styles.sendingContainer}>
          <Icon name={"send-sharp"} color={"#1F3A93"} size={30} />
        </View>
      </Send>
    );
  }
  function scrollToBottomComponent() {
    return (
      <View style={styles.bottomComponentContainer}>
        <Icon name={"chevron-down-circle"} color={"#1F3A93"} size={30} />
      </View>
    );
  }
  function renderLoading() {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1F3A93" />
      </View>
    );
  }

  const onSend = useCallback((messages = []) => {
    setMessages((previousMessages) =>
      GiftedChat.append(previousMessages, messages)
    );
  }, []);

  const sendPushNotification = (text) => {
    console.log(text);
    fetch("https://fcm.googleapis.com/fcm/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `key=AAAAXNqwt_I:APA91bEaXiMsR1g8M2-3l0cBZm_8e_1L8mjrC-nWZGbGD0P-XkDN2BAvsFhQh1oHQxlv0eSIuE_T1vrUoe66VOY3yk0f9P7-tSs0Eb0mJa3say76a4_NgIGIrPZ_AuSaer_vvKF-lOG_`,
      },
      body: JSON.stringify({
        to: expoPushToken,
        priority: "normal",
        data: {
          experienceId: "@tshepomathatho/HealthA",
          scopeKey: "@tshepomathatho/HealthA",
          title: "New Message",
          message: text,
        },
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  function handleSend(newMessage = []) {
    const text = newMessage[0].text;

    sendPushNotification(text);

    setLoading(true);

    setMessages(GiftedChat.append(messages, newMessage));

    db.collection("chats").add({
      text,
      createdAt: new Date().getTime(),
      consult_id: consult_id,
      user: {
        _id: user_id,
      },
    });
  }

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#fff",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <ActivityIndicator size="large" color="#1F3A93" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <GiftedChat
        messages={messages}
        showAvatarForEveryMessage={false}
        onSend={(newMessage) => handleSend(newMessage)}
        placeholder="Type your message here..."
        renderSend={renderSend}
        scrollToBottom
        scrollToBottomComponent={scrollToBottomComponent}
        renderLoading={renderLoading}
        user={{
          _id: user_id,
        }}
      />
      <View
        style={{
          position: "absolute", //use absolute position to show button on top of the map
          top: "5%", //for center align
          alignSelf: "flex-end", //for align to right
        }}
      >
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{
            backgroundColor: "#1F3A93",
            borderWidth: 2,
            borderColor: "#DCE1F7",
            width: "100%",
            alignItems: "center",
            borderRadius: 30,
          }}
        >
          <Icon name={"close"} color={"#fff"} size={35} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ChatScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  sendingContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  bottomComponentContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
