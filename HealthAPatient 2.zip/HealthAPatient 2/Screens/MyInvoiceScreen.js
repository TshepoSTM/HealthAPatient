import "react-native-gesture-handler";
import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  StatusBar,
  TouchableHighlight,
  SafeAreaView,
  FlatList,
  Alert,
  ImageBackground,
  ActivityIndicator,
  Modal,
  TextInput,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Icon from "react-native-vector-icons/Ionicons";
import axios from "axios";
import { url_key, myApiKey } from "../config/url_key";

export default class MyInvoiceScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      invoiceData: [],
      searchData: [],
      search: "",
      userToken: "",
      modalVisible: false,
      isLoading: false,
      isContent: true,
    };
  }

  searchFilterFunction = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState({ search: val });

    console.log(val);

    //console.log(this.state.invoiceData)
    const newData = this.state.invoiceData.filter((item) => {
      const itemData = `${item.invno.toUpperCase()} ${item.pname.toUpperCase()}`;

      const textData = val.toUpperCase();

      return itemData.indexOf(textData) > -1;
    });
    console.log(newData);
    this.setState({ searchData: newData });
  };

  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
    this.setState({ searchData: [] });
  };

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });
      //console.log('user token',userToken);
    } catch (error) {
      console.log(error);
    }
  };

  getMyInvoices(userToken) {
    var param = {};
    var data = {
      name: "getMyInvoices",
      param: param,
      token: JSON.parse(userToken),
    };

    //console.log(data);
    axios({
      url: url_key + "getMyInvoices",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          console.log(response.data);
          this.setState({ invoiceData: response.data });
          this.setState({ isLoading: false });
          this.setState({ isContent: false });
        },
        (error) => {
          console.log(error.response.data);
        }
      )
      .catch((error) => {
        console.log(error.response.data);
      });
  }

  renderInvoiceComponent = (invoiceData) => (
    <View style={styles.consultationView}>
      <TouchableOpacity
        onPress={() =>
          this.props.navigation.navigate("InvoiceDetails", {
            invno: invoiceData.item.invno,
            pname: invoiceData.item.pname,
            date: invoiceData.item.date,
            duedate: invoiceData.item.duedate,
            amount: invoiceData.item.amount,
            accHolder: invoiceData.item.accHolder,
            accNo: invoiceData.item.accNo,
            accType: invoiceData.item.accType,
            address1: invoiceData.item.address1,
            address2: invoiceData.item.address2,
            bankName: invoiceData.item.bankName,
            branchCode: invoiceData.item.branchCode,
            code: invoiceData.item.code,
            contactPerson: invoiceData.item.contactPerson,
            email: invoiceData.item.email,
            mobile: invoiceData.item.mobile,
            padr1: invoiceData.item.padr1,
            padr2: invoiceData.item.padr2,
            paid: invoiceData.item.paid,
            pcode: invoiceData.item.pcode,
            pemail: invoiceData.item.pemail,
            pmobile: invoiceData.item.pmobile,
            pname: invoiceData.item.pname,
            practice_name: invoiceData.item.practice_name,
          })
        }
        style={styles.patatientContatiner}
      >
        <Image
          source={require("../assets/avatar1.png")}
          style={styles.patientImage}
        />
        <View
          style={{
            alignSelf: "flex-start",
            paddingHorizontal: 5,
            paddingVertical: 0,
            borderRadius: 20,
            marginTop: 0,
            marginLeft: 10,
            borderColor: "#fff",
            borderWidth: 1,
          }}
        >
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                Invoice Number
              </Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                #{invoiceData.item.invno}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                Full names
              </Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                {invoiceData.item.pname}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>Date</Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                {invoiceData.item.date}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                Due Date
              </Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                {invoiceData.item.duedate}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                Invoice Total
              </Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                R{invoiceData.item.amount}
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );

  componentDidMount() {
    this.getToken();
    this.willFocusSubscription = this.props.navigation.addListener(
      "focus",
      () => {
        this.getToken();
      }
    );
  }

  render() {
    const { modalVisible } = this.state;

    if (this.state.isLoading) {
      return (
        <View
          style={{
            flex: 1,
            backgroundColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ActivityIndicator size="large" color="#1F3A93" />
        </View>
      );
    }
    return (
      <View style={styles.container}>
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
              <Icon
                name={Platform.OS === "ios" ? "md-arrow-back" : "md-arrow-back"}
                color={"#1F3A93"}
                size={35}
              />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                Invoices
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity onPress={() => this.setModalVisible(true)}>
              <Icon
                name={Platform.OS === "ios" ? "md-search" : "md-search"}
                color={"#1F3A93"}
                size={35}
              />
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            {this.state.isContent ? (
              <View style={styles.hcpStatus}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 18, color: "#1F3A93" }}
                >
                  No Records
                </Text>
              </View>
            ) : (
              <SafeAreaView></SafeAreaView>
            )}

            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible}
              onRequestClose={() => {
                this.setModalVisible(!modalVisible);
              }}
            >
              <View style={styles.centeredView}>
                <View style={styles.modalView}>
                  <View style={styles.modalHeader}>
                    <View style={styles.searchInputView2}>
                      <TextInput
                        placeholderTextColor={"#000"}
                        placeholder="Search"
                        value={this.state.search}
                        onChangeText={(val) =>
                          this.searchFilterFunction(val, "search")
                        }
                        style={styles.search_input}
                        keyboardAppearance="light"
                      />
                    </View>
                    <TouchableOpacity
                      style={{ backgroundColor: "#1F3A93", borderRadius: 20 }}
                      onPress={() => this.setModalVisible(!modalVisible)}
                    >
                      <Icon
                        name={Platform.OS === "ios" ? "md-close" : "md-close"}
                        color={"#fff"}
                        size={30}
                      />
                    </TouchableOpacity>
                  </View>

                  <SafeAreaView>
                    <FlatList
                      data={this.state.searchData}
                      renderItem={(item) => this.renderInvoiceComponent(item)}
                      keyExtractor={(item) => item.invno.toString()}
                      nestedScrollEnabled={true}
                    />
                  </SafeAreaView>
                </View>
              </View>
            </Modal>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 0,
    marginTop: 0,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  productsContainer: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#302121",
    borderRadius: 10,
  },
  totalContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 15,
    borderRadius: 10,
    backgroundColor: "#302121",
  },
  checkoutContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productContent: {
    marginTop: 10,
    marginBottom: 10,
  },
  consultationView: {
    marginVertical: 5,
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  patatientContatiner: {
    flexDirection: "row",
    margin: 0,
    width: "100%",
    alignItems: "center",
    alignContent: "center",
  },
  patientImage: {
    height: 60,
    width: 60,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    marginLeft: 0,
  },
  addressContent: {
    width: "100%",
  },
  patientButtons: {
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "#1F3A93",
    marginHorizontal: 0,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
  hcpStatus: {
    marginVertical: 5,
    margin: 0,
    alignItems: "center",
    alignContent: "center",
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
    backgroundColor: "#fff",
  },
  modalContent: {
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 4,
    borderColor: "rgba(0, 0, 0, 0.1)",
    margin: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    marginTop: 10,
    margin: 5,
  },
  modalView: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  searchInputView2: {
    flexDirection: "row",
    width: "90%",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#1F3A93",
    borderColor: "#302121",
    paddingRight: 10,
  },
  search_input: {
    color: "#000",
    fontSize: 14,
    paddingLeft: 5,
    flex: 1,
    fontFamily: "normal",
  },
});
