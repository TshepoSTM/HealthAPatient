import React, { Component } from "react";
import {
  StyleSheet,
  Dimensions,
  Text,
  TextInput,
  View,
  Button,
  TouchableHighlight,
  Modal,
  TouchableOpacity,
  Image,
  ScrollView,
  StatusBar,
  ActivityIndicator,
  Alert,
  SafeAreaView,
} from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import AntDesign from "@expo/vector-icons/AntDesign";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import * as Notifications from "expo-notifications";
import * as DocumentPicker from "expo-document-picker";
import * as Device from "expo-device";
import axios from "axios";
import Dialog, {
  DialogTitle,
  DialogContent,
  DialogFooter,
  DialogButton,
  SlideAnimation,
  ScaleAnimation,
} from "react-native-popup-dialog";
import SelectDropdown from "react-native-select-dropdown";
import { MultiSelect } from "react-native-element-dropdown";
import { url_key, myApiKey } from "../config/url_key";

export default class SignUpScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstname: "",
      surname: "",
      adr1: "",
      adr2: "",
      province: "",
      provinces: [],
      selectedProvince: "",
      code: "",
      idNumber: "",
      cellphone: "",
      email: "",
      password: "",
      confpassword: "",
      expoPushToken: "",
      cardNumber: "",
      pic: "",
      picName: "",
      medSchemeData: [],
      selectedMedSchems: [],
      isLoading: false,
      errorMessage: "",
      errorfirstname: "",
      errorSurname: "",
      errorIdNumber: "",
      errorEmail: "",
      errorCellphone: "",
      errorPassword: "",
      errorConfpassword: "",
      errorAdr1: "",
      errorAdr2: "",
      errorProvince: "",
      errorCode: "",
      errorMedicalAid: "",
      errorMedicalAidNo: "",
      showDialog: false,
      showMedNum: true,
      modalVisible: false,
      verCode: "",
      errorVerCode: "",
    };
  }
  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorfirstname: "" });
    this.setState({ errorSurname: "" });
    this.setState({ errorAdr1: "" });
    this.setState({ errorAdr2: "" });
    this.setState({ errorProvince: "" });
    this.setState({ errorCode: "" });
    this.setState({ errorIdNumber: "" });
    this.setState({ errorCellphone: "" });
    this.setState({ errorEmail: "" });
    this.setState({ errorPassword: "" });
    this.setState({ errorMedicalAid: "" });
    this.setState({ errorVerCode: "" });
    this.setState({ errorMedicalAidNo: "" });
    this.setState({ errorMessage: "" });
  };

  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
  };

  validateEmail = (email) => {
    //console.log(email);
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,6})+$/;
    if (reg.test(email) === false) {
      //console.log("Email is Not Correct");
      this.setState({ errorEmail: "Your email is Invalid " });
      this.setState({ email: email });
      return false;
    } else {
      this.setState({ email: email });
      console.log("Email is Correct");
      this.setState({ errorEmail: "Email is correct" });
    }
  };

  registerForPushNotificationsAsync = async () => {
    let token;

    if (Device.isDevice) {
      const { status: existingStatus } =
        await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      if (existingStatus !== "granted") {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      if (finalStatus !== "granted") {
        alert("Failed to get push token for push notification!");
        return;
      }
      try {
        const projectId = "30ba5c89-d44d-4ae9-ab41-60a07d7b95e9"; //Constants?.expoConfig?.extra?.eas?.projectId ?? Constants?.easConfig?.projectId;
        if (!projectId) {
          throw new Error("Project ID not found");
        }
        token = (
          await Notifications.getDevicePushTokenAsync({
            projectId,
          })
        ).data;
        console.log(token);
      } catch (e) {
        token = `${e}`;
      }
    } else {
      alert("Must use physical device for Push Notifications");
    }
    this.setState({ expoPushToken: token });
    //return token;
  };

  onselectedMedSchemsChange = (selectedMedSchems) => {
    this.setState({ selectedMedSchems });

    for (let i = 0; i < selectedMedSchems.length; i++) {
      console.log(selectedMedSchems[i]);

      if (selectedMedSchems[i] == 1) {
        this.setState({ showMedNum: false });
      } else {
        this.setState({ showMedNum: true });
      }
    }
  };

  onDialogDismis() {
    this.setState({ showDialog: false });
  }

  getMedSchemes() {
    var data = { name: "getMedSchemes", param: {} };
    axios({
      url: url_key + "getMedSchemes",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          this.setState({ medSchemeData: response.data });
          this.setState({ isLoading: false });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  pickDocument = async () => {
    let result = await DocumentPicker.getDocumentAsync({
      type: "*/*",
      copyToCacheDirectory: true,
    }).then((response) => {
      console.log(response.type);
      if (response.type == "success") {
        let { name, size, uri } = response;
        let nameParts = name.split(".");
        let fileType = nameParts[nameParts.length - 1];

        var fileToUpload = {
          name: name,
          size: size,
          uri: uri,
          type: "application/" + fileType,
        };
        console.log(fileToUpload, "...............file");
        //this.postDocument(fileToUpload);
        this.setState({ pic: fileToUpload });
        this.setState({ picName: fileToUpload.name });
      }
    });
    console.log(this.state.pic);
  };

  registerUser() {
    if (this.state.firstname == "") {
      this.setState({ errorfirstname: "Enter first name" });
    }
    if (this.state.surname == "") {
      this.setState({ errorSurname: "Enter surname" });
    }
    if (this.state.adr1 == "") {
      this.setState({ errorAdr1: "Enter Address 1" });
    }
    if (this.state.adr2 == "") {
      this.setState({ errorAdr2: "Enter Address 2" });
    }
    if (this.state.selectedProvince == "") {
      this.setState({ errorProvince: "Enter Province" });
    }
    if (this.state.code == "") {
      this.setState({ errorCode: "Enter Code" });
    }
    if (this.state.idNumber == "" || this.state.idNumber.length != 13) {
      this.setState({ errorIdNumber: "Enter Valid ID" });
      return;
    }
    if (this.state.cellphone == "" || this.state.cellphone.length != 10) {
      this.setState({ errorCellphone: "Enter cellphone" });
      return;
    }
    if (this.state.email == "") {
      this.setState({ errorEmail: "Enter email" });
    }
    if (this.state.password == "") {
      this.setState({ errorPassword: "Enter password" });
    }
    if (this.state.password != this.state.confpassword) {
      this.setState({ errorConfpassword: "Passwords does not match" });
    }
    if (this.state.selectedMedSchems == "") {
      this.setState({ errorMedicalAid: "Select medical aid" });
    }

    if (
      this.state.firstname != "" &&
      this.surname != "" &&
      this.state.cellphone != "" &&
      this.state.idNumber != "" &&
      this.state.email != "" &&
      this.state.password
    ) {
      var param = {
        expoPushToken: this.state.expoPushToken,
        name: this.state.firstname,
        surname: this.state.surname,
        roleId: 2,
        adr1: this.state.adr1,
        adr2: this.state.adr2,
        province: this.state.selectedProvince,
        code: this.state.code,
        idno: this.state.idNumber,
        mobile: this.state.cellphone,
        email: this.state.email,
        password: this.state.password,
        cardNumber: this.state.cardNumber,
        confirm_password: this.state.confpassword,
        medicalAidIDs: this.state.selectedMedSchems.toString(),
      };

      var data = { name: "addUser", param: param };

      this.setState({ isLoading: true });

      console.log(data);

      axios({
        url: url_key + "addUser",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);
            if (response.data.res == true) {
              this.setState({ isLoading: false });

              this.setModalVisible(true);

              /*this.setState({ showDialog: true });
                        setTimeout(() => {
                            this.setState({ showDialog: false });
                            this.props.navigation.navigate('SignIn');
                        }, 5000);*/
            } else {
              this.setState({ isLoading: false });
              this.setState({ errorMessage: response.data.error.message });
            }
          },
          (error) => {
            console.log(error.response.data);
            this.setState({ isLoading: false });
          }
        )
        .catch((error) => {
          console.log(error.response.data);
          this.setState({ isLoading: false });
        });
    }
  }

  verifyCode() {
    if (this.state.verCode == "") {
      this.setState({ errorVerCode: "Invalid verification code" });
    }

    if (this.state.verCode != "") {
      var param = { ver_code: this.state.verCode };
      var data = { name: "verifyCode", param: param };

      console.log(data);

      axios({
        url: url_key + "verifyCode",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);
            if (response.data == true) {
              this.setModalVisible(false);
              this.setState({ showDialog: true });
              setTimeout(() => {
                this.setState({ showDialog: false });
                this.props.navigation.navigate("SignIn");
              }, 5000);
            } else {
              this.setState({ errorVerCode: "Invalid verification code" });
            }
          },
          (error) => {
            console.log(error);
          }
        )
        .catch((error) => {
          console.log(error);
        });
    }
  }

  componentDidMount() {
    this.registerForPushNotificationsAsync();
    this.getMedSchemes();

    if (this.props.route.params == undefined) {
      console.log("undefined");
    } else {
      this.setState({
        email: this.props.route.params.email,
        firstname: this.props.route.params.firstname,
        surname: this.props.route.params.surname,
        picName: this.props.route.params.picName,
      });
    }
  }

  render() {
    const { modalVisible } = this.state;
    const { selectedMedSchems } = this.state;
    const province = [
      "Limpopo",
      "Gauteng",
      "North West",
      "Mpumalanga",
      "Free State",
      "Northen Cape",
      "Eastern Cape",
      "Western Cape",
      "Kwa Zulu Natal",
    ];

    if (this.state.isLoading) {
      return (
        <View
          style={{
            flex: 1,
            backgroundColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ActivityIndicator size="large" color="#1F3A93" />
        </View>
      );
    }

    return (
      <SafeAreaView style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.header}>
          <Text style={styles.text_header}>PERSONAL INFORMATION</Text>
        </View>

        <Dialog
          visible={this.state.showDialog}
          dialogAnimation={
            new SlideAnimation({
              slideFrom: "bottom",
            })
          }
          onTouchOutside={() => this.onDialogDismis()}
          onHardwareBackPress={() => this.onDialogDismis()}
          dialogTitle={
            <DialogTitle
              title="Congratulations"
              style={{
                backgroundColor: "#F7F7F8",
              }}
              hasTitleBar={false}
              align="center"
            />
          }
          footer={
            <DialogFooter>
              <DialogButton
                text="OK"
                bordered
                onPress={() => this.onDialogDismis()}
                key="button-1"
              />
            </DialogFooter>
          }
        >
          <DialogContent
            style={{ alignItems: "center", justifyContent: "center" }}
          >
            <Ionicons name={"check-circle"} color={"green"} size={50} />
            <Text>You are successfully registered.</Text>
          </DialogContent>
        </Dialog>

        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            this.setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView1}>
            <View style={styles.modalView1}>
              <View style={styles.modalHeader}>
                <View
                  style={{ justifyContent: "center", alignItems: "center" }}
                >
                  <Text style={{ fontSize: 20, color: "#1F3A93" }}>
                    Check verification code sent via SMS
                  </Text>
                </View>
              </View>

              <SafeAreaView>
                <View style={styles.consultationView}>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Enter Verification Code"}
                      keyboardType={"numeric"}
                      numeric
                      value={this.state.verCode}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "verCode")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorVerCode}
                    </Text>
                  </View>

                  <View
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 5,
                    }}
                  >
                    <TouchableOpacity
                      style={styles.loginBtn}
                      onPress={() => this.verifyCode()}
                    >
                      <Text style={styles.loginText}>Verify</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </SafeAreaView>
            </View>
          </View>
        </Modal>

        <View style={styles.footer}>
          <ScrollView style={{ backgroundColor: "#FAFAFA", margin: 2 }}>
            <View style={{ flexDirection: "row", marginTop: 5 }}>
              <TextInput
                style={styles.textInput}
                placeholder="First Name"
                value={this.state.firstname}
                onChangeText={(val) => this.updateInputsVal(val, "firstname")}
              />
              <TextInput
                style={styles.textInput}
                placeholder="Surname"
                value={this.state.surname}
                onChangeText={(val) => this.updateInputsVal(val, "surname")}
              />
            </View>
            <View style={{ flexDirection: "row", marginTop: 0 }}>
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorfirstname}
              </Text>
              <Text
                style={[
                  styles.texterror,
                  { color: "#1F3A93", paddingLeft: 80 },
                ]}
              >
                {this.state.errorSurname}
              </Text>
            </View>

            <View style={{ flexDirection: "row", marginTop: 0 }}>
              <TextInput
                style={styles.textInput}
                placeholder="Address 1"
                value={this.state.adr1}
                onChangeText={(val) => this.updateInputsVal(val, "adr1")}
              />
              <TextInput
                style={styles.textInput}
                placeholder="Address 2"
                value={this.state.adr2}
                onChangeText={(val) => this.updateInputsVal(val, "adr2")}
              />
            </View>
            <View style={{ flexDirection: "row", marginTop: 0 }}>
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorAdr1}
              </Text>
              <Text
                style={[
                  styles.texterror,
                  { color: "#1F3A93", paddingHorizontal: 80 },
                ]}
              >
                {this.state.errorAdr2}
              </Text>
            </View>

            <View style={{ flexDirection: "row", marginTop: 0 }}>
              <SelectDropdown
                data={province}
                onSelect={(selectedItem, index) => {
                  console.log(selectedItem, index);
                  this.setState({ selectedProvince: selectedItem });
                }}
                renderButton={(selectedItem, isOpened) => {
                  return (
                    <View style={styles.dropdownButtonStyle}>
                      <Text style={styles.dropdownButtonTxtStyle}>
                        {(selectedItem && selectedItem) || "Select Province"}
                      </Text>
                    </View>
                  );
                }}
                renderItem={(item, index, isSelected) => {
                  return (
                    <View
                      style={{
                        ...styles.dropdownItemStyle,
                        ...(isSelected && { backgroundColor: "#fff" }),
                      }}
                    >
                      <Text style={styles.dropdownItemTxtStyle}>{item}</Text>
                    </View>
                  );
                }}
                showsVerticalScrollIndicator={false}
                dropdownStyle={styles.dropdownMenuStyle}
              />
              <TextInput
                style={styles.textInput}
                placeholder="Code"
                value={this.state.code}
                onChangeText={(val) => this.updateInputsVal(val, "code")}
              />
              {/*<View style={styles.textInput}>
                            <TouchableOpacity onPress={()=> this.pickDocument()}><Icon name={Platform.OS === "ios" ? "image" : "image" } color={'#000'} size={20} /></TouchableOpacity>
                            <Text style={{paddingHorizontal:5,paddingVertical:0,fontSize:12}}>{this.state.picName}</Text>
                        </View>*/}
            </View>
            <View style={{ flexDirection: "row", marginTop: 0 }}>
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorProvince}
              </Text>
              <Text
                style={[
                  styles.texterror,
                  { color: "#1F3A93", paddingHorizontal: 80 },
                ]}
              >
                {this.state.errorCode}
              </Text>
            </View>

            {/*<MultiSelect
              items={this.state.medSchemeData}
              uniqueKey="id"
              ref={(component) => {
                this.multiSelect = component;
              }}
              onSelectedItemsChange={this.onselectedMedSchemsChange}
              selectedItems={selectedMedSchems}
              selectText="Choose medical aid"
              searchInputPlaceholderText="Search Items..."
              onChangeInput={(text) => console.log(text)}
              tagRemoveIconColor="#CCC"
              tagBorderColor="#CCC"
              tagTextColor="#CCC"
              selectedItemTextColor="#CCC"
              selectedItemIconColor="#CCC"
              itemTextColor="#000"
              displayKey="name"
              searchInputStyle={{ color: "#CCC" }}
              submitButtonColor="#1F3A93"
              submitButtonText="Confirm"
              styleMainWrapper={{ margin: 5, paddingVertical: 0 }}
              styleDropdownMenu={{ margin: 5 }}
            /> */}
            <MultiSelect
              style={styles.dropdown}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              inputSearchStyle={styles.inputSearchStyle}
              iconStyle={styles.iconStyle}
              search
              data={this.state.medSchemeData}
              labelField="name"
              valueField="id"
              placeholder="Select item"
              searchPlaceholder="Search..."
              value={selectedMedSchems}
              onChange={this.onselectedMedSchemsChange}
              selectedStyle={styles.selectedStyle}
            />

            <View>
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorMedicalAid}
              </Text>
              {/*<Text>{selectedMedSchems}</Text>*/}
            </View>

            {this.state.showMedNum ? (
              <View style={styles.action}>
                <TextInput
                  placeholder={"Medical Aid No."}
                  autoCapitalize="none"
                  value={this.state.cardNumber}
                  onChangeText={(val) =>
                    this.updateInputsVal(val, "cardNumber")
                  }
                  style={styles.text_input}
                />
                <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                  {this.state.errorIdNumber}
                </Text>
              </View>
            ) : (
              <View></View>
            )}

            <Text style={styles.text_footer}></Text>

            <View style={styles.action}>
              <TextInput
                placeholder={"ID Number"}
                autoCapitalize="none"
                value={this.state.idNumber}
                maxLength={13}
                keyboardType={"numeric"}
                numeric
                onChangeText={(val) => this.updateInputsVal(val, "idNumber")}
                style={styles.text_input}
              />
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorIdNumber}
              </Text>
            </View>
            <Text style={styles.text_footer}></Text>
            <View style={styles.action}>
              <TextInput
                placeholder={"Cellphone"}
                autoCapitalize="none"
                value={this.state.cellphone}
                maxLength={10}
                keyboardType={"numeric"}
                numeric
                onChangeText={(val) => this.updateInputsVal(val, "cellphone")}
                style={styles.text_input}
              />
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorCellphone}
              </Text>
            </View>
            <Text style={styles.text_footer}></Text>
            <View style={styles.action}>
              <TextInput
                placeholder={"Email"}
                autoCapitalize="none"
                value={this.state.email}
                onChangeText={(email) => this.validateEmail(email)}
                style={styles.text_input}
              />
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorEmail}
              </Text>
            </View>
            <Text style={[styles.text_footer, { marginTop: 0 }]}></Text>
            <View style={styles.action}>
              <TextInput
                placeholder={"Password"}
                secureTextEntry={true}
                value={this.state.password}
                onChangeText={(val) => this.updateInputsVal(val, "password")}
                style={styles.text_input}
              />
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorPassword}
              </Text>
            </View>
            <Text style={[styles.text_footer, { marginTop: 0 }]}></Text>
            <View style={styles.action}>
              <TextInput
                placeholder={"Corfirm Password"}
                secureTextEntry={true}
                value={this.state.confpassword}
                onChangeText={(val) =>
                  this.updateInputsVal(val, "confpassword")
                }
                style={styles.text_input}
              />
              <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                {this.state.errorConfpassword}
              </Text>
            </View>
            <Text style={[styles.texterror, { color: "#1F3A93" }]}>
              {this.state.errorMessage}
            </Text>
            <View style={styles.navButton}>
              <View style={{ alignItems: "flex-start", width: "70%" }}>
                <TouchableOpacity
                  onPress={() => this.props.navigation.navigate("SignIn")}
                  style={{
                    backgroundColor: "#1F3A93",
                    borderWidth: 2,
                    borderColor: "#DCE1F7",
                    width: "25%",
                    alignItems: "center",
                    borderRadius: 20,
                  }}
                >
                  <Ionicons name={"arrow-back"} color={"#fff"} size={35} />
                </TouchableOpacity>
              </View>
              <View style={{ alignItems: "flex-start", width: "30%" }}>
                <TouchableOpacity
                  onPress={() => this.registerUser()}
                  style={{
                    backgroundColor: "#1F3A93",
                    borderWidth: 2,
                    borderColor: "#DCE1F7",
                    width: "100%",
                    height: 40,
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: 20,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 18,
                      color: "#fff",
                      textAlign: "center",
                    }}
                  >
                    Register
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1F3A93",
    paddingHorizontal: 0,
    paddingBottom: 5,
  },
  footer: {
    flex: 4,
    backgroundColor: "#fff",
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    paddingHorizontal: 12,
    paddingVertical: 15,
    margin: 1,
  },
  text_header: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 28,
  },
  text_footer: {
    fontSize: 18,
    color: "black",
  },
  action: {
    flexDirection: "row",
    marginTop: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#d9d4d9",
    paddingBottom: 0,
  },
  navButton: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  text_input: {
    flex: 1,
    paddingLeft: 3,
    color: "#000",
    fontSize: 16,
  },
  title: {
    color: "#561b6e",
    fontWeight: "bold",
    fontSize: 25,
  },
  text: {
    color: "black",
    marginTop: 5,
  },
  button: {
    alignItems: "center",
    marginTop: 50,
  },
  signIn: {
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold",
  },
  textForgotPass: {
    fontSize: 12,
  },
  texterror: {
    fontSize: 12,
    margin: 2,
  },
  textInput: {
    fontSize: 16,
    marginTop: 5,
    borderBottomColor: "#302121",
    marginLeft: 2,
    borderBottomWidth: 1,
    paddingBottom: 0,
    paddingVertical: 0,
    width: "50%",
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  centeredView1: {
    flex: 1,
    justifyContent: "center",
    marginTop: 10,
    margin: 5,
  },
  modalView1: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  action: {
    flexDirection: "row",
    marginTop: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#d9d4d9",
    paddingBottom: 0,
  },

  dropdownButtonStyle: {
    width: 180,
    height: 50,
    backgroundColor: "#FAFAFA",
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#302121",
  },
  dropdownButtonTxtStyle: {
    flex: 1,
    fontSize: 16,
    fontWeight: "normal",
    color: "#151E26",
  },
  dropdownButtonArrowStyle: {
    fontSize: 28,
  },
  dropdownButtonIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },
  dropdownMenuStyle: {
    backgroundColor: "#E9ECEF",
    borderRadius: 8,
  },
  dropdownItemStyle: {
    width: "100%",
    flexDirection: "row",
    paddingHorizontal: 12,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 8,
  },
  dropdownItemTxtStyle: {
    flex: 1,
    fontSize: 16,
    fontWeight: "normal",
    color: "#151E26",
  },
  dropdownItemIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },

  dropdown: {
    height: 50,
    backgroundColor: "transparent",
    borderBottomColor: "gray",
    borderBottomWidth: 0.5,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 14,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
  icon: {
    marginRight: 5,
  },
  selectedStyle: {
    borderRadius: 12,
  },
});
