import {
  useKeepAwake,
  activateKeepAwakeAsync,
  deactivateKeepAwake,
} from "expo-keep-awake";
import React, { Component, createRef } from "react";
import {
  StyleSheet,
  Text,
  View,
  Button,
  TouchableOpacity,
  Dimensions,
  StatusBar,
  ActivityIndicator,
  Alert,
  SafeAreaView,
  Modal,
  TextInput,
} from "react-native";
import { Image } from "expo-image";
import Icon from "react-native-vector-icons/Ionicons";
import Dialog, {
  DialogTitle,
  DialogContent,
  DialogFooter,
  DialogButton,
  SlideAnimation,
  ScaleAnimation,
} from "react-native-popup-dialog";
import MapView, { Marker, Polyline, Circle } from "react-native-maps";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Location from "expo-location";
import MapViewDirections from "react-native-maps-directions";
import * as geolib from "geolib";
import axios from "axios";
import { url_key, myApiKey } from "../config/url_key";

const GOOGLE_MAPS_APIKEY = "AIzaSyD2Ik8CMlQ1JtjfJiButRHEDgv77djZy0c";

const mapRef = createRef(null);
const { width, height } = Dimensions.get("window");
const ASPECT_RATIO = width / height;

export default class MapsScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      distance: null,
      locations: "",
      address: "",
      time: 0,
      distance: 0,
      decline_status: "",
      user_id: this.props.route.params.user_id,
      userToken: "",
      stage: this.props.route.params.stage,
      con_id: this.props.route.params.con_id,
      hcp_id: this.props.route.params.hcp_id,
      nxtStage: this.props.route.params.nxtStage,
      hcp_lat: parseFloat(this.props.route.params.hcp_lat),
      hcp_long: parseFloat(this.props.route.params.hcp_long),
      location: null,
      geocode: null,
      region: null,
      latitude: 0,
      longitude: 0,
      user_loc: null,
      user_geocode: null,
      isShowing: false,
      isCancel: true,
      showDialog: false,
      user_address: "",
      modalVisible: false,
      modalVisible1: false,
      modalVisible2: false,
      isLoading: false,
      expoPushToken: "",
      verCode: "",
      comment: "",
      errorVerCode: "",
      errorComment: "",
      coordinates: [
        {
          latitude: -23.90116,
          longitude: 29.42467,
        },
        {
          latitude: -23.901238,
          longitude: 29.43211,
        },
      ],
    };

    //this.mapView = null;
  }

  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorVerCode: "" });
    this.setState({ errorComment: "" });
  };

  getLocationAsync = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") {
      this.setState({
        errorPermMessage: "Permission denied",
      });
    }

    let location = await Location.getCurrentPositionAsync({});

    //console.log(location.coords);
    const { latitude, longitude } = location.coords;
    //this.getGeocodeAsync({latitude,longitude})

    this.calculateDistance(location.coords.latitude, location.coords.longitude);

    this.setState({ location: { latitude, longitude } });
    this.setState({ latitude: location.coords.latitude });
    this.setState({ longitude: location.coords.longitude });

    this.setState({
      region: {
        latitude,
        longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      },
    });
  };

  getGeocodeAsync = async (location) => {
    let geocode = await Location.reverseGeocodeAsync(location);
    //console.log(geocode);
    this.setState({ geocode });
    this.setState({
      address: geocode
        ? `${geocode[0].name},${geocode[0].street},${geocode[0].district},${geocode[0].city}`
        : "",
    });
  };

  getUserAddress = async (user_loc) => {
    //console.log(user_loc)
    this.calculateDistance(user_loc.latitude, user_loc.longitude);
    let user_geocode = await Location.reverseGeocodeAsync(user_loc);
    console.log(user_geocode);
    this.setState({ user_geocode });
    this.setState({
      user_address: user_geocode
        ? `${user_geocode[0].name},${user_geocode[0].street},${user_geocode[0].district},${user_geocode[0].city}`
        : "",
    });
  };

  onRegionChange(region) {
    //console.log(region)
    this.setState({ region });
  }

  onDialogDismis() {
    this.setState({ showDialog: false });
  }

  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
  };

  setModalVisible1 = (visible1) => {
    this.setState({ modalVisible1: visible1 });
  };

  setModalVisible2 = (visible2) => {
    this.setState({ modalVisible2: visible2 });
  };

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });
      //console.log('user token',userToken);
      this.getHCPpushToken(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  getHCPpushToken = (userToken) => {
    var param = { hcp_id: this.props.route.params.hcp_id };
    var data = {
      name: "getHCPpushToken",
      param: param,
      token: JSON.parse(userToken),
    };

    axios({
      url: url_key + "getHCPpushToken",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //this.setState({expoPushToken:response.data.expoPushToken})
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  };

  calculateDistance(latitude, longitude) {
    var dis = getDistance(
      { latitude: latitude, longitude: longitude },
      {
        latitude: parseFloat(this.props.route.params.pat_lat),
        longitude: parseFloat(this.props.route.params.pat_lon),
      }
    );

    //return dis / 1000
    //console.log(dis / 1000);
  }

  sendPushNotification(msg) {
    fetch("https://fcm.googleapis.com/fcm/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `key=AAAAXNqwt_I:APA91bEaXiMsR1g8M2-3l0cBZm_8e_1L8mjrC-nWZGbGD0P-XkDN2BAvsFhQh1oHQxlv0eSIuE_T1vrUoe66VOY3yk0f9P7-tSs0Eb0mJa3say76a4_NgIGIrPZ_AuSaer_vvKF-lOG_`,
      },
      body: JSON.stringify({
        to: this.state.expoPushToken,
        priority: "normal",
        data: {
          experienceId: "@tshepomathatho/HealthA",
          scopeKey: "@tshepomathatho/HealthA",
          title: "Health-A Consultation",
          message: "Consultation Cancelled" + msg,
        },
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  cancelConsulatation() {
    Alert.alert(
      "Cornfirmation",
      "Are you sure, you want to cancel?",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "OK",
          onPress: () => {
            this.sendPushNotification();

            var param = {
              consultId: this.state.con_id,
              hcp_id: this.state.hcp_id,
              user_id: this.state.user_id,
            };

            var data = {
              name: "deleteConsultation",
              param: param,
              token: JSON.parse(this.state.userToken),
            };
            //console.log(data);

            axios({
              url: url_key + "deleteConsultation",
              method: "POST",
              data: data,
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
            })
              .then(
                (response) => {
                  //console.log(response.data);
                  if (response.data == true) {
                    this.setState({ showDialog: true });
                    setTimeout(() => {
                      this.setState({ showDialog: false });
                      this.props.navigation.push("Home");
                    }, 2000);
                  } else {
                    console.log(response.data);
                  }
                },
                (error) => {
                  console.log(error);
                }
              )
              .catch((error) => {
                console.log(error);
              });
          },
        },
      ],
      { cancelable: false }
    );
  }

  cancelTrip() {
    var msg = "";
    if (this.state.comment == "") {
      this.setState({ errorComment: "Enter comment" });
    }

    if (this.state.comment != "") {
      var param = {
        con_id: this.state.con_id,
        hcp_id: this.state.hcp_id,
        user_id: this.state.user_id,
        comment: this.state.comment,
      };

      var data = {
        name: "cancelTrip",
        param: param,
        token: JSON.parse(this.state.userToken),
      };

      axios({
        url: url_key + "cancelTrip",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data.res);

            if (response.data.res == true) {
              if (response.data.charged == "Yes") {
                msg = " with charges.";
                this.sendPushNotification(msg);
                this.setModalVisible2(false);
              } else {
                this.sendPushNotification(msg);
              }

              this.setState({ showDialog: true });
              setTimeout(() => {
                this.setState({ showDialog: false });
                this.props.navigation.push("Home");
              }, 2000);
            } else {
              console.log(response.data);
            }
          },
          (error) => {
            console.log(error.response.data);
          }
        )
        .catch((error) => {
          console.log(error.response.data);
        });
    }
  }

  declineConsultation() {
    var param = {
      consultId: this.state.con_id,
      hcp_id: this.state.hcp_id,
      user_id: this.state.user_id,
    };

    var data = {
      name: "deleteConsultation",
      param: param,
      token: JSON.parse(this.state.userToken),
    };
    console.log(data);

    axios({
      url: url_key + "deleteConsultation",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          if (response.data == true) {
            //this.setState({showDialog:true});
            setTimeout(() => {
              this.props.navigation.push("Home");
            }, 2000);
          } else {
            console.log(response.data);
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getConsultationStatus() {
    var param = {
      con_id: this.state.con_id,
      hcp_id: this.state.hcp_id,
      user_id: this.state.user_id,
    };
    var data = {
      name: "getConsultationStatus",
      param: param,
      token: JSON.parse(this.state.userToken),
    };

    axios({
      url: url_key + "getConsultationStatus",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          if (response.data.stage == "Request sent") {
            this.setState({ isShowing: true });
            this.setState({ isCancel: false });
          } else if (response.data.stage == "Closed") {
            this.props.navigation.navigate("Home", {
              con_id: this.state.con_id,
            });
          } else if (response.data.stage == "Rating") {
            this.props.navigation.navigate("Home", {
              con_id: this.state.con_id,
            });
          } else {
            this.setState({ isShowing: false });
            this.setState({ stage: response.data.stage });
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getLiveCoordinates() {
    var param = {
      con_id: this.state.con_id,
      hcp_id: this.state.hcp_id,
      user_id: this.state.user_id,
    };
    var data = {
      name: "getLiveCoordinates",
      param: param,
      token: JSON.parse(this.state.userToken),
    };

    //console.log(data);

    axios({
      url: url_key + "getLiveCoordinates",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);

          if (response.data == null) {
            //console.log(this.state.hcp_lat);
            this.setState({ hcp_lat: this.state.hcp_lat });
            this.setState({ hcp_long: this.state.hcp_long });
          } else {
            this.setState({ hcp_lat: parseFloat(response.data.latitude) });
            this.setState({ hcp_long: parseFloat(response.data.longitude) });
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  checkHealthRecordStatus() {
    var param = {
      con_id: this.state.con_id,
      hcp_id: this.state.hcp_id,
      user_id: this.state.user_id,
    };
    var data = {
      name: "checkHealthRecordStatus",
      param: param,
      token: JSON.parse(this.state.userToken),
    };

    axios({
      url: url_key + "checkHealthRecordStatus",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          if (response.data == 1) {
            this.setModalVisible(true);
          } else {
            this.setModalVisible(false);
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  checkDeclinedConsultation() {
    var param = {
      con_id: this.state.con_id,
      hcp_id: this.state.hcp_id,
      user_id: this.state.user_id,
    };
    var data = {
      name: "checkDeclinedConsultation",
      param: param,
      token: JSON.parse(this.state.userToken),
    };

    axios({
      url: url_key + "checkDeclinedConsultation",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          if (response.data == 0) {
            return;
          } else {
            this.setModalVisible1(true);
            this.setState({ decline_status: response.data.reason });
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  acceptHealthRequest() {
    if (this.state.verCode == "") {
      this.setState({ errorVerCode: "Invalid verification code" });
    }

    if (this.state.verCode != "") {
      var param = {
        con_id: this.state.con_id,
        hcp_id: this.state.hcp_id,
        user_id: this.state.user_id,
        ver_code: this.state.verCode,
      };
      var data = {
        name: "acceptHealthRequest",
        param: param,
        token: JSON.parse(this.state.userToken),
      };

      console.log(data);

      axios({
        url: url_key + "acceptHealthRequest",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);
            if (response.data == false) {
              this.setState({ errorVerCode: "Invalid verification code" });
            } else {
              console.log("true");
            }
          },
          (error) => {
            console.log(error);
          }
        )
        .catch((error) => {
          console.log(error);
        });
    }
  }

  _activateScreen = () => {
    activateKeepAwakeAsync();
  };

  _setMapReady = (pat_lat, pat_lon, hcp_lat, hcp_long) => {
    /*if (_map.current) {
      _map.current.fitToCoordinates([origin, destination], {
        edgePadding: { top: 10, right: 10, bottom: 10, left: 10 },
        animated: true,
      });
    }*/
    if (mapRef.current) {
      mapRef.current.fitToCoordinates(
        [
          { pat_lat, pat_lon },
          { hcp_lat, hcp_long },
        ],
        {
          edgePadding: { top: 10, right: 10, bottom: 10, left: 10 },
          animated: true,
        }
      );
    }
  };

  componentDidMount() {
    this.getToken();
    this.getLocationAsync();
    this._activateScreen();
    //this.calculateDistance();
    setInterval(() => {
      this.getConsultationStatus();
    }, 5000);

    setInterval(() => {
      this.getLiveCoordinates();
      this.checkHealthRecordStatus();
      this.checkDeclinedConsultation();
    }, 9000);
  }

  render() {
    const { modalVisible } = this.state;
    const { modalVisible1 } = this.state;
    const { modalVisible2 } = this.state;

    console.log(this.props.route.params);
    let pat_lat = parseFloat(this.props.route.params.pat_lat);
    let pat_lon = parseFloat(this.props.route.params.pat_lon);

    let hcp_lat = this.state.hcp_lat;
    let hcp_long = this.state.hcp_long;

    let coordinates = [
      {
        latitude: this.state.hcp_lat,
        longitude: this.state.hcp_long,
      },
      {
        latitude: pat_lat,
        longitude: pat_lon,
      },
    ];

    return (
      <SafeAreaView style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <Dialog
          visible={this.state.showDialog}
          dialogAnimation={
            new SlideAnimation({
              slideFrom: "bottom",
            })
          }
          onTouchOutside={() => this.onDialogDismis()}
          onHardwareBackPress={() => this.onDialogDismis()}
          dialogTitle={
            <DialogTitle
              title="Cancelling"
              style={{
                backgroundColor: "#F7F7F8",
              }}
              hasTitleBar={false}
              align="center"
            />
          }
          footer={
            <DialogFooter>
              <DialogButton
                text="OK"
                bordered
                onPress={() => this.onDialogDismis()}
                key="button-1"
              />
            </DialogFooter>
          }
        >
          <DialogContent
            style={{ alignItems: "center", justifyContent: "center" }}
          >
            <Icon name={"checkmark-circle"} color={"green"} size={50} />
            <Text>Consultation cancelled</Text>
          </DialogContent>
        </Dialog>

        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            this.setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView1}>
            <View style={styles.modalView1}>
              <View style={styles.modalHeader}>
                <View
                  style={{ justifyContent: "center", alignItems: "center" }}
                >
                  <Text style={{ fontSize: 18, color: "#1F3A93" }}>
                    HCP has requested your medical record. Check verification
                    code sent via SMS
                  </Text>
                </View>
              </View>

              <SafeAreaView>
                <View style={styles.consultationView}>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Enter Verification Code"}
                      keyboardType={"numeric"}
                      numeric
                      value={this.state.verCode}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "verCode")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorVerCode}
                    </Text>
                  </View>

                  <View
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 5,
                    }}
                  >
                    <TouchableOpacity
                      style={styles.loginBtn}
                      onPress={() => this.acceptHealthRequest()}
                    >
                      <Text style={styles.loginText}>Accept</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </SafeAreaView>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible1}
          onRequestClose={() => {
            this.setModalVisible1(!modalVisible1);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <View style={styles.modalHeader}>
                <View
                  style={{ justifyContent: "center", alignItems: "center" }}
                >
                  <Text style={{ fontSize: 20, color: "#1F3A93" }}>
                    Your consultation has been declined
                  </Text>
                </View>
              </View>

              <SafeAreaView>
                <View style={styles.modalContent}>
                  <View
                    style={{ justifyContent: "center", alignItems: "center" }}
                  >
                    <Text style={{ fontSize: 16, color: "#1F3A93" }}>
                      Reason: {this.state.decline_status}
                    </Text>
                  </View>
                  <TouchableOpacity
                    style={styles.loginBtn}
                    onPress={() => this.declineConsultation()}
                  >
                    <Text style={styles.loginText}>OK</Text>
                  </TouchableOpacity>
                </View>
              </SafeAreaView>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible2}
          onRequestClose={() => {
            this.setModalVisible2(!modalVisible2);
          }}
        >
          <View style={styles.centeredView1}>
            <View style={styles.modalView1}>
              <View style={styles.modalHeader2}>
                <View style={styles.searchInputView2}>
                  <Text style={{ fontSize: 20, color: "#1F3A93" }}>
                    Cancelling Consultation
                  </Text>
                </View>
                <TouchableOpacity
                  style={{ backgroundColor: "#1F3A93", borderRadius: 20 }}
                  onPress={() => this.setModalVisible2(false)}
                >
                  <Icon name={"close"} color={"#fff"} size={30} />
                </TouchableOpacity>
              </View>

              <SafeAreaView>
                <View
                  style={{ justifyContent: "center", alignItems: "center" }}
                ></View>
                <View style={styles.consultationView}>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Enter Comment"}
                      value={this.state.comment}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "comment")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorComment}
                    </Text>
                  </View>

                  <View
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 5,
                    }}
                  >
                    <TouchableOpacity
                      style={styles.loginBtn}
                      onPress={() => this.cancelTrip()}
                    >
                      <Text style={styles.loginText}>Submit</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </SafeAreaView>
            </View>
          </View>
        </Modal>

        {this.state.isShowing ? (
          <View
            styles={{
              flex: 1,
              alignItems: "center",
              alignSelf: "center",
              justifyContent: "center",
            }}
          >
            <View style={{ alignItems: "center", alignSelf: "center" }}>
              <ActivityIndicator size="large" color="#1F3A93" />
              <MapView
                style={styles.onloadMap}
                initialRegion={this.state.region}
              />
              <Text style={{ color: "#fff" }}>Waiting for HCP to accept..</Text>
            </View>
          </View>
        ) : (
          <View>
            <MapView
              style={styles.maps}
              ref={mapRef}
              initialRegion={this.state.region}
              userLocationPriority="high"
              userLocationUpdateInterval={100}
              onMapReady={this._setMapReady(
                pat_lat,
                pat_lon,
                hcp_lat,
                hcp_long
              )}
            >
              <Marker
                style={styles.markerStyle}
                coordinate={{
                  latitude: this.state.hcp_lat,
                  longitude: this.state.hcp_long,
                }}
                onDragEnd={
                  (e) =>
                    this.getUserAddress(
                      e.nativeEvent.coordinate
                    ) /* {console.log('dragEnd', e.nativeEvent.coordinate)}*/
                }
                //identifier={"mk1"}
                title="HCP"
                redraw={true}
              >
                <Image
                  source={
                    "https://batcave.healtha.co.za/uploads/assets/hcp.png"
                  }
                  style={{ height: 30, width: 30 }}
                />
              </Marker>

              <Marker
                style={styles.markerStyle}
                coordinate={{ latitude: pat_lat, longitude: pat_lon }}
                onDragEnd={
                  (e) =>
                    this.getUserAddress(
                      e.nativeEvent.coordinate
                    ) /* {console.log('dragEnd', e.nativeEvent.coordinate)}*/
                }
                //identifier={"mk2"}
                title="Me"
              />

              <MapViewDirections
                origin={{
                  latitude: this.state.hcp_lat,
                  longitude: this.state.hcp_long,
                  latitudeDelta: 0.003,
                  longitudeDelta: 0.003,
                }}
                destination={{ latitude: pat_lat, longitude: pat_lon }}
                apikey={GOOGLE_MAPS_APIKEY}
                strokeWidth={7}
                strokeColor="#3399ff"
                mode="DRIVING"
                lineDashPattern={[1]}
                onReady={(result) => {
                  //console.log(result)
                  let d = result.distance.toFixed(2);
                  let t = result.duration.toFixed(2);

                  this.setState({ distance: d });
                  this.setState({ time: t });
                }}
              />
            </MapView>
          </View>
        )}
        <View
          style={{
            position: "absolute", //use absolute position to show button on top of the map
            top: "5%", //for center align
            alignSelf: "flex-end", //for align to right
          }}
        >
          {/*
						<TouchableOpacity onPress={()=> this.props.navigation.push('Home')} style={{backgroundColor:'#1F3A93',borderWidth:2,borderColor:'#DCE1F7',width:'100%',alignItems:'center',borderRadius:5}}>
							<Icon name={Platform.OS === "ios" ? "md-arrow-back" : "md-arrow-back" } color={'#fff'} size={35} />
						</TouchableOpacity>
						
						<TouchableOpacity onPress={()=> this.props.navigation.navigate('Chat')} style={{backgroundColor:'#1F3A93',borderWidth:2,borderColor:'#DCE1F7',width:'100%',alignItems:'center',borderRadius:5}}>
                            <Icon name={Platform.OS === "ios" ? "md-chatbox-ellipses-outline" : "md-chatbox-ellipses-outline" } color={'#fff'} size={35} />
                        </TouchableOpacity>*/}
          <TouchableOpacity
            onPress={() => console.log("back")}
            style={{
              backgroundColor: "#1F3A93",
              borderWidth: 2,
              borderColor: "#DCE1F7",
              width: "100%",
              alignItems: "center",
              borderRadius: 5,
            }}
          >
            <Icon name={"arrow-back"} color={"#fff"} size={35} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => this.props.navigation.push("Home")}
            style={{
              backgroundColor: "#1F3A93",
              borderWidth: 2,
              borderColor: "#DCE1F7",
              width: "100%",
              alignItems: "center",
              borderRadius: 5,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 8 }}>
              {this.state.distance} km
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => this.props.navigation.push("Home")}
            style={{
              backgroundColor: "#1F3A93",
              borderWidth: 2,
              borderColor: "#DCE1F7",
              width: "100%",
              alignItems: "center",
              borderRadius: 5,
            }}
          >
            <Text style={{ color: "#fff", fontSize: 8 }}>
              {this.state.time} m
            </Text>
          </TouchableOpacity>
        </View>
        <View
          style={{
            backgroundColor: "#1F3A93",
            width: "100%",
            paddingVertical: 0,
            flexDirection: "row",
            top: "93%",
            position: "absolute",
          }}
        >
          <View style={{ alignItems: "center", width: "30%" }}>
            <TouchableOpacity
              style={{ alignItems: "center", marginVertical: 10, margin: 5 }}
            >
              <Text
                style={{
                  fontWeight: "bold",
                  color: "#fff",
                  fontSize: 14,
                  margin: 5,
                }}
              >
                {this.state.stage}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={{ alignItems: "center", width: "23%" }}>
            {this.state.isCancel ? (
              <View>
                <TouchableOpacity
                  onPress={() => this.setModalVisible2()}
                  style={{
                    alignItems: "center",
                    backgroundColor: "#d11f00",
                    borderRadius: 5,
                    marginVertical: 10,
                    margin: 5,
                  }}
                >
                  <Text
                    style={{
                      fontWeight: "bold",
                      color: "#fff",
                      fontSize: 14,
                      margin: 5,
                    }}
                  >
                    Cancel
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View></View>
            )}
          </View>
          <View style={{ alignItems: "center", width: "75%" }}>
            {this.state.isShowing ? (
              <View>
                <TouchableOpacity
                  onPress={() => this.cancelConsulatation()}
                  style={{
                    alignItems: "center",
                    backgroundColor: "#fff",
                    borderColor: "#fff",
                    borderRadius: 5,
                    marginVertical: 10,
                    margin: 5,
                    borderWidth: 1,
                  }}
                >
                  <Text
                    style={{
                      fontWeight: "bold",
                      color: "#1F3A93",
                      fontSize: 14,
                      margin: 5,
                    }}
                  >
                    Cancel
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View>
                <TouchableOpacity
                  onPress={() =>
                    this.props.navigation.navigate("Chat", {
                      con_id: this.state.con_id,
                      user_id: this.state.user_id,
                      hcp_id: this.state.hcp_id,
                    })
                  }
                  style={{ alignItems: "center", width: "15%", margin: 5 }}
                >
                  <Icon
                    name={"chatbox-ellipses-outline"}
                    color={"#fff"}
                    size={35}
                  />
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  maps: {
    width: "100%", //Dimensions.get("screen").width,
    height: "100%", //Dimensions.get("screen").height,
  },
  onloadMap: {
    width: Dimensions.get("screen").width,
    height: Dimensions.get("screen").height,
    position: "absolute",
    opacity: 0.2,
  },
  markerStyle: {},
  centeredView1: {
    flex: 1,
    justifyContent: "center",
    marginTop: 10,
    margin: 5,
  },
  modalView1: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    marginTop: 10,
    margin: 5,
  },
  modalView: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
    backgroundColor: "#fff",
  },
  modalContent: {
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 4,
    borderColor: "rgba(0, 0, 0, 0.1)",
    margin: 0,
  },
  action: {
    flexDirection: "row",
    marginTop: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#d9d4d9",
    paddingBottom: 0,
  },
  texterror: {
    fontSize: 12,
    margin: 2,
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  text_input: {
    flex: 1,
    paddingLeft: 5,
    color: "#000",
    fontSize: 16,
  },
  modalHeader2: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
    marginHorizontal: 10,
    backgroundColor: "#fff",
  },
  searchInputView2: {
    flexDirection: "row",
    width: "90%",
    alignItems: "center",
    borderBottomColor: "#1F3A93",
    borderColor: "#302121",
    paddingRight: 10,
  },
  search_input: {
    color: "#000",
    fontSize: 14,
    paddingLeft: 5,
    flex: 1,
    fontFamily: "normal",
  },
});
