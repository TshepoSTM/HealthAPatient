import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  StatusBar,
  SafeAreaView,
  TextInput,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import { url_key, myApiKey } from "../config/url_key";
import axios from "axios";

export default class ResetPassScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      cart_data: [],
      email: "",
      password: "",
      isLoading: false,
      errorMessage: "",
      errorEmail: "",
      errorPassword: "",
      cust_id_fk: "",
      check: "",
    };
  }

  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorEmail: "" });
    this.setState({ errorPassword: "" });
    this.setState({ errorMessage: "" });
  };

  ForgotPass() {
    if (this.state.email == "") {
      this.setState({ errorEmail: "Enter email" });
    }

    if (this.state.email != "") {
      var param = { emailaddress: this.state.email };

      var data = { name: "veryfyemail", param: param };
      console.log(data);

      axios({
        url: url_key + "veryfyemail",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);
            if (response.data.error) {
              //console.warn(response.data.error.message)
              this.setState({ errorMessage: response.data.error.message });
            } else {
              if (response.data.response.results == true) {
                this.setState({ errorMessage: response.data.response.message });

                setTimeout(() => {
                  this.props.navigation.navigate("Forgot", {
                    email: this.state.email,
                  });
                }, 2000);
              } else {
                this.setState({ errorMessage: response.data.response.message });
              }
              console.log(response.data.response.results);
            }
          },
          (error) => {
            console.log(error);
          }
        )
        .catch((error) => {
          console.log(error);
        });
    }
  }

  render() {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity></TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            ></View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
              <Icon name={"close"} color="#1F3A93" size={30} />
            </TouchableOpacity>
          </View>
        </View>

        <View>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            <Text
              style={{ fontSize: 22, fontWeight: "bold", color: "#1F3A93" }}
            >
              Forgort Your Password
            </Text>
            <Text style={{ fontSize: 16, color: "#000", marginTop: 20 }}>
              Here you can easily retrieve/create a new password.
            </Text>
            <TextInput
              style={styles.textInput}
              placeholder="Email"
              autoCapitalize="none"
              value={this.state.email}
              onChangeText={(val) => this.updateInputsVal(val, "email")}
            />
            <Text style={[styles.texterror, { color: "#1F3A93" }]}>
              {this.state.errorEmail}
            </Text>
            <Text style={[styles.texterror, { color: "#1F3A93" }]}>
              {this.state.errorMessage}
            </Text>
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                marginTop: 40,
              }}
            >
              <TouchableOpacity
                style={styles.loginBtn}
                onPress={() => this.ForgotPass()}
              >
                <Text style={styles.loginText}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 15,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  textInput: {
    fontSize: 16,
    marginTop: 40,
    borderBottomColor: "#302121",
    marginLeft: 2,
    borderBottomWidth: 1,
    paddingBottom: 0,
    paddingVertical: 15,
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  texterror: {
    fontSize: 12,
  },
});
