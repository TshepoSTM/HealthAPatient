import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TouchableHighlight,
  SafeAreaView,
  FlatList,
  Alert,
  ImageBackground,
  TextInput,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import SectionedMultiSelect from "react-native-sectioned-multi-select";
//import MultiSelect from "react-native-multiple-select";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Icon from "react-native-vector-icons/MaterialIcons";
import * as Location from "expo-location";
import axios from "axios";
import { url_key, myApiKey, logo_url } from "../config/url_key";
import { getDistance, getPreciseDistance } from "geolib";

export default class HCPScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      symptomsData: [],
      selectedSymptoms: [],
      medSchemeData: [],
      selectedMedSchems: [],
      med_aid: "",
      symps: [],
      latitude: null,
      longitude: null,
      hcp_lat: this.props.route.params.latitude,
      hcp_long: this.props.route.params.longitude,
      k_dis: "",
      problem_desc: "",
      errorDescription: "",
      errorSymptoms: "",
      userToken: "",
      isConsult: false,
      isLoading: true,
      expoPushToken: "",
    };
  }
  getLocationAsync = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") {
      this.setState({
        errorPermMessage: "Permission denied",
      });
    }

    let location = await Location.getCurrentPositionAsync();

    const { latitude, longitude } = location.coords;

    this.calculateDistance(location.coords.latitude, location.coords.longitude);

    this.setState({ location: { latitude, longitude } });
    this.setState({ latitude: location.coords.latitude });
    this.setState({ longitude: location.coords.longitude });
    this.setState({
      region: {
        latitude,
        longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      },
    });
  };

  calculateDistance(latitude, longitude) {
    var dis = getDistance(
      { latitude: latitude, longitude: longitude },
      {
        latitude: this.props.route.params.latitude,
        longitude: this.props.route.params.longitude,
      }
    );
    var k_dis = dis / 1000;
    this.setState({ k_dis: k_dis });
    //console.log(this.props.route.params.latitude+','+this.props.route.params.longitude);
  }

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });
      //console.log('user token',userToken);
      this.getHCPpushToken(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  getSymptoms() {
    var data = { name: "getSymptoms", param: {} };
    axios({
      url: url_key + "getSymptoms",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(JSON.stringify(response.data));
          this.setState({ symptomsData: response.data });
          this.setState({ isLoading: false });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getMedSchemes() {
    var data = { name: "getMedSchemes", param: {} };
    axios({
      url: url_key + "getMedSchemes",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          this.setState({ medSchemeData: response.data });
          this.setState({ isLoading: false });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  onSelectedSymptomsChange = (selectedSymptoms) => {
    this.setState({ selectedSymptoms });
  };

  onselectedMedSchemsChange = (selectedMedSchems) => {
    this.setState({ selectedMedSchems });
  };

  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorDescription: "" });
    this.setState({ errorSymptoms: "" });
    this.setState({ errorYear: "" });
    this.setState({ errorFile: "" });
  };

  isConsulting() {
    this.setState({ isConsult: !this.state.isConsult });
  }

  getHCPpushToken = (userToken) => {
    var param = { hcp_id: this.props.route.params.hcp_id };
    var data = {
      name: "getHCPpushToken",
      param: param,
      token: JSON.parse(userToken),
    };

    axios({
      url: url_key + "getHCPpushToken",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data.expoPushToken);
          this.setState({ expoPushToken: response.data.expoPushToken });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  };

  sendPushNotification() {
    console.log(this.state.expoPushToken);
    fetch("https://fcm.googleapis.com/fcm/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `key=AAAAXNqwt_I:APA91bEaXiMsR1g8M2-3l0cBZm_8e_1L8mjrC-nWZGbGD0P-XkDN2BAvsFhQh1oHQxlv0eSIuE_T1vrUoe66VOY3yk0f9P7-tSs0Eb0mJa3say76a4_NgIGIrPZ_AuSaer_vvKF-lOG_`,
      },
      body: JSON.stringify({
        to: this.state.expoPushToken,
        priority: "normal",
        data: {
          experienceId: "@tshepomathatho/HealthA",
          scopeKey: "@tshepomathatho/HealthA",
          title: "Health-A Consultation",
          message: "Consultation requested",
        },
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  submitData() {
    if (this.state.selectedSymptoms == "") {
      this.setState({ errorSymptoms: "Select symptomps" });
    }
    if (this.state.problem_desc == "") {
      this.setState({ errorSymptoms: "Describe your problem" });
    }

    if (this.state.selectedSymptoms != "" && this.state.problem_desc != "") {
      var param = {
        hcp_id: this.props.route.params.hcp_id,
        latitude: this.state.latitude.toString(),
        longitude: this.state.longitude.toString(),
        problem_desc: this.state.problem_desc,
        symptomIDs: this.state.selectedSymptoms.toString(),
      };

      var data = {
        name: "saveConsultation",
        param: param,
        token: JSON.parse(this.state.userToken),
      };

      this.sendPushNotification();

      console.log(data);

      this.setState({ isLoading: true });

      axios({
        url: url_key + "saveConsultation",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);
            if (response.data == true) {
              this.setState({ isLoading: false });
              this.setState({ isConsult: false });
              alert("Consultation logged");
              this.setState({ isLoading: false });

              setTimeout(() => {
                this.props.navigation.navigate("Home");
              }, 1000);
            }
          },
          (error) => {
            console.log(error.response.data);
            this.setState({ isLoading: false });
          }
        )
        .catch((error) => {
          console.log(error.response.data);
          this.setState({ isLoading: false });
        });
    }
  }

  componentDidMount() {
    this.getToken();
    this.getLocationAsync();
    this.getSymptoms();
    this.getMedSchemes();
    if (this.props.route.params.accept_medical_aid == 0) {
      this.setState({ med_aid: "No" });
    } else {
      this.setState({ med_aid: "Yes" });
    }

    //console.log(this.props.route.params)
  }

  render() {
    let sp = this.props.route.params.sp;
    let symps = this.props.route.params.sym;
    let colors = ["#03453c", "#ffa200", "#c23b29", "#04910b", "#635c5e"];

    let speciality = sp.map((myValue, myIndex) => {
      //var newIndexV = (myIndex + 1).toString();

      //console.log(myValue.newIndexV);
      return (
        <TouchableOpacity
          style={{
            backgroundColor: colors[myIndex],
            borderWidth: 1,
            borderColor: "#fff",
            borderRadius: 10,
          }}
          key={myValue.newIndexV}
        >
          <Text
            style={{
              fontSize: 12,
              color: "#fff",
              alignContent: "center",
              justifyContent: "center",
              marginHorizontal: 5,
              marginVertical: 5,
              margin: 5,
            }}
          >
            {myValue.name}
          </Text>
        </TouchableOpacity>
      );
    });

    let symptomps = symps.map((myValue, myIndex) => {
      //var newIndexV = (myIndex + 1).toString();

      //console.log(myValue.newIndexV);
      return (
        <TouchableOpacity
          style={{
            backgroundColor: colors[myIndex],
            borderWidth: 1,
            borderColor: "#fff",
            borderRadius: 10,
          }}
          key={myValue.newIndexV}
        >
          <Text
            style={{
              fontSize: 12,
              color: "#fff",
              marginHorizontal: 5,
              marginVertical: 5,
              margin: 5,
            }}
          >
            {myValue.name}
          </Text>
        </TouchableOpacity>
      );
    });
    const { selectedSymptoms } = this.state;
    const { selectedMedSchems } = this.state;

    if (this.state.isLoading) {
      return (
        <View
          style={{
            flex: 1,
            backgroundColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ActivityIndicator size="large" color="#1F3A93" />
        </View>
      );
    }

    return (
      <View style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
              <Icon name={"arrow-back"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                HCP Details
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity></TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            <SafeAreaView>
              <View style={styles.consultationView}>
                <View style={styles.patatientContatiner}>
                  <Image
                    source={
                      !this.props.route.params.profile_pic
                        ? "https://batcave.healtha.co.za/uploads/assets/avatar1.png"
                        : {
                            uri:
                              logo_url +
                              "logo/" +
                              this.props.route.params.profile_pic,
                          }
                    }
                    style={styles.patientImage}
                  />
                  <View
                    style={{
                      alignSelf: "flex-start",
                      paddingHorizontal: 0,
                      paddingVertical: 0,
                      borderRadius: 20,
                      marginTop: 0,
                      marginLeft: 20,
                      borderColor: "#fff",
                      borderWidth: 1,
                    }}
                  >
                    <View style={{ flexDirection: "row" }}>
                      <View
                        style={{
                          width: "50%",
                          alignItems: "flex-start",
                          alignSelf: "flex-start",
                          justifyContent: "flex-start",
                        }}
                      >
                        <Text style={{ fontWeight: "bold" }}>
                          {this.props.route.params.full_names}
                        </Text>
                      </View>
                      <View
                        style={{
                          alignItems: "flex-end",
                          alignSelf: "flex-end",
                          justifyContent: "flex-end",
                        }}
                      >
                        <Text
                          style={{
                            fontWeight: "bold",
                            paddingHorizontal: 20,
                            marginHorizontal: 10,
                          }}
                        >
                          {this.state.k_dis}km
                        </Text>
                      </View>
                    </View>
                    <View style={{ flexDirection: "row", paddingVertical: 5 }}>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.props.route.params.address1 +
                          ", " +
                          this.props.route.params.address2 +
                          ", " +
                          this.props.route.params.code}
                      </Text>
                    </View>
                    <View style={{ flexDirection: "row", paddingVertical: 10 }}>
                      <TouchableOpacity></TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => this.isConsulting()}
                        style={styles.patientButtons}
                      >
                        <Text style={{ color: "#fff" }}>Consult</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "25%" }}>
                    <Text style={{ fontWeight: "normal" }}>Full Names:</Text>
                  </View>
                  <View style={{ width: "70%" }}>
                    <Text
                      style={{ paddingHorizontal: 0, marginHorizontal: 20 }}
                    >
                      {this.props.route.params.full_names}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "30%" }}>
                    <Text style={{ fontWeight: "normal" }}>Contact No.:</Text>
                  </View>
                  <View>
                    <Text style={{ paddingHorizontal: 0, marginHorizontal: 5 }}>
                      {this.props.route.params.mobile}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "25%" }}>
                    <Text style={{ fontWeight: "normal" }}>Distance:</Text>
                  </View>
                  <View style={{ width: "70%" }}>
                    <Text
                      style={{ paddingHorizontal: 0, marginHorizontal: 20 }}
                    >
                      {this.state.k_dis}km
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "25%" }}>
                    <Text style={{ fontWeight: "normal" }}>
                      Consultation Fee:
                    </Text>
                  </View>
                  <View style={{ width: "60%" }}>
                    <Text
                      style={{ paddingHorizontal: 0, marginHorizontal: 20 }}
                    >
                      R {this.props.route.params.consultation_fee}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "25%" }}>
                    <Text style={{ fontWeight: "normal" }}>
                      Accept Med Aid:
                    </Text>
                  </View>
                  <View style={{ width: "60%" }}>
                    <Text
                      style={{ paddingHorizontal: 0, marginHorizontal: 20 }}
                    >
                      {this.state.med_aid}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "25%" }}>
                    <Text style={{ fontWeight: "normal" }}>Symptoms:</Text>
                  </View>
                  <View style={{ width: "60%" }}>
                    <Text
                      style={{ paddingHorizontal: 0, marginHorizontal: 20 }}
                    >
                      {speciality}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", marginLeft: 8 }}>
                  <View style={{ width: "25%" }}>
                    <Text style={{ fontWeight: "normal" }}>Symptoms:</Text>
                  </View>
                  <View style={{ width: "60%" }}>
                    <Text
                      style={{ paddingHorizontal: 0, marginHorizontal: 20 }}
                    >
                      {symptomps}
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.consultationView}>
                {this.state.isConsult ? (
                  <View>
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: "bold",
                        color: "#1F3A93",
                      }}
                    >
                      Consultation
                    </Text>
                    <SectionedMultiSelect
                      items={this.state.symptomsData}
                      IconRenderer={Icon}
                      uniqueKey="id"
                      subKey="list"
                      selectText="Choose symptoms..."
                      showDropDowns={true}
                      readOnlyHeadings={true}
                      onSelectedItemsChange={this.onSelectedSymptomsChange}
                      selectedItems={this.state.selectedSymptoms}
                    />
                    <View>
                      <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                        {this.state.errorSymptoms}
                      </Text>
                      {/*<Text>{selectedSymptoms}</Text>*/}
                    </View>

                    <View style={styles.action}>
                      <TextInput
                        placeholder={"Description"}
                        autoCapitalize="none"
                        multiline={true}
                        value={this.state.problem_desc}
                        onChangeText={(val) =>
                          this.updateInputsVal(val, "problem_desc")
                        }
                        style={styles.text_input}
                      />
                      <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                        {this.state.errorDescription}
                      </Text>
                    </View>

                    <View style={styles.navButton}>
                      <TouchableOpacity
                        onPress={() => this.submitData()}
                        style={[
                          styles.registerButton,
                          {
                            borderColor: "#1F3A93",
                            borderWidth: 1,
                            marginTop: 10,
                            backgroundColor: "#1F3A93",
                            marginLeft: 5,
                          },
                        ]}
                      >
                        <Text style={[styles.textRegister, { color: "#fff" }]}>
                          Submit
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ) : (
                  <View></View>
                )}
              </View>
            </SafeAreaView>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 15,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  productsContainer: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#302121",
    borderRadius: 10,
  },
  totalContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 15,
    borderRadius: 10,
    backgroundColor: "#302121",
  },
  checkoutContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productContent: {
    marginTop: 10,
    marginBottom: 10,
  },
  consultationView: {
    marginVertical: 5,
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  patatientContatiner: {
    flexDirection: "row",
    margin: 0,
  },
  patientImage: {
    height: 50,
    alignSelf: "center",
    width: 50,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    marginLeft: 8,
  },
  patientButtons: {
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "#1F3A93",
    marginHorizontal: 5,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 15,
  },
  showMore: {
    marginLeft: 8,
  },
  showMoreContent: {
    fontWeight: "normal",
  },
  action: {
    flexDirection: "row",
    marginTop: 5,
    borderBottomWidth: 1,
    borderBottomColor: "#d9d4d9",
    paddingBottom: 5,
  },
  text_input: {
    flex: 1,
    paddingLeft: 10,
    color: "#000",
    fontSize: 16,
  },
  texterror: {
    fontSize: 12,
  },
  navButton: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    margin: 5,
  },
  registerButton: {
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  textRegister: {
    fontSize: 16,
    fontWeight: "bold",
    paddingHorizontal: 10,
  },
});
