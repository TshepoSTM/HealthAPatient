import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  ActivityIndicator,
  SafeAreaView,
  FlatList,
  Modal,
  TextInput,
} from "react-native";
import { Image } from "expo-image";
import Icon from "react-native-vector-icons/Ionicons";
import Ionicons from "@expo/vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Location from "expo-location";
import axios from "axios";
import { url_key, myApiKey, logo_url } from "../config/url_key";
import { getDistance, getPreciseDistance } from "geolib";
//import StarRating from "react-native-star-rating";
//import StarRating from "react-native-star-rating-widget";
import { Rating, RatingInput } from "react-native-stock-star-rating";

export default class PortalScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userToken: "",
      data: [],
      hcpData: [],
      hcp_Data: [],
      symNames: [],
      searchHCP: [],
      coordinates: [],
      distance: [],
      lats: [],
      longs: [],
      address: "",
      search: "",
      pic: "",
      med_aid: "",
      avatarImg: null ? { uri: null } : require("../assets/avatar.png"),
      expoPushToken: "",
      modalVisible: false,
      modalVisible1: false,
      location: null,
      geocode: null,
      latitude: null,
      longitude: null,
      showMore: false,
      isLoading: false,
      arrayholder: [],
      searchData: [],
      starCount: 1,
      con_id: "",
    };
  }

  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
    this.setState({ searchData: [] });
  };

  setModalVisible1 = (visible) => {
    this.setState({ modalVisible1: visible });
  };

  ShowMore() {
    this.setState({ showMore: !this.state.showMore });
  }

  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState({ search: val });
  };

  onStarRatingPress(rating) {
    this.setState({
      starCount: rating,
    });
    console.log(rating);
  }

  submitRating() {
    var param = { rating: this.state.starCount, con_id: this.state.con_id };

    var data = {
      name: "rateConsultation",
      param: param,
      token: JSON.parse(this.state.userToken),
    };

    console.log(data);

    axios({
      url: "http://batcave.healtha.co.za/Administration/rateConsultation",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          console.log(response.data);
          this.setModalVisible1(false);
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getLocationAsync = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") {
      this.setState({
        errorPermMessage: "Permission denied",
      });
    }

    let location = await Location.getCurrentPositionAsync({});

    /*navigator.geolocation.getCurrentPosition((position) => {
            console.log(position.coords.latitude, position.coords.longitude);
            let latitude =  position.coords.latitude;
            let longitude =  position.coords.longitude;
            this.getGeocodeAsync({latitude,longitude})
          },{

          },{
            enableHighAccuracy: true
          });

    let location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.BestForNavigation,
    });*/

    const { latitude, longitude } = location.coords;
    //this.getGeocodeAsync({latitude,longitude})

    this.setState({ location: { latitude, longitude } });
    this.setState({ latitude: location.coords.latitude });
    this.setState({ longitude: location.coords.longitude });
    this.setState({
      region: {
        latitude,
        longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      },
    });
  };

  calculateDistance(latitude, longitude) {
    for (let index = 0; index < this.state.hcpData.length; index++) {
      //console.log(this.state.hcpData[index].latitude)
      var dist = [];
      dist[index] = getDistance(
        { latitude: latitude, longitude: longitude },
        {
          latitude: this.state.hcpData[index].latitude,
          longitude: this.state.hcpData[index].longitude,
        }
      );
      this.setState({ distance: dist[index] / 1000 });
      //console.log(dist[index]/1000);
    }
  }

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });

      this.getUser(userToken);
      this.getConsultsPatient(userToken);
      this.getHCPs(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  getUser(userToken) {
    var param = {};
    var data = { name: "getUser", param: param, token: JSON.parse(userToken) };

    axios({
      url: url_key + "getUser",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          this.setState({ pic: null });
          if (response.data.image == "") {
            this.setState({ avatarImg: require("../assets/avatar.png") });
          } else {
            this.setState({
              avatarImg: { uri: logo_url + "logo/" + response.data.image },
            });
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getHCPs(userToken) {
    var param = {};
    var data = { name: "getHCPs", param: param, token: JSON.parse(userToken) };

    axios({
      url: url_key + "getHCPs",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          //this.setState({ isLoading: false });

          setTimeout(() => {
            var loc = this.state.location;

            function calculateDistance(lat1, lon1, lat2, lon2) {
              var radlat1 = (Math.PI * lat1) / 180;
              var radlat2 = (Math.PI * lat2) / 180;
              var radlon1 = (Math.PI * lon1) / 180;
              var radlon2 = (Math.PI * lon2) / 180;
              var theta = lon1 - lon2;

              var radtheta = (Math.PI * theta) / 180;
              var dist =
                Math.sin(radlat1) * Math.sin(radlat2) +
                Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
              dist = Math.acos(dist);
              dist = (dist * 180) / Math.PI;
              dist = dist * 60 * 1.1515;

              //dist = dist.toFixed(2);

              return dist;
            }

            for (let i = 0; i < response.data.length; i++) {
              response.data[i]["distance"] = calculateDistance(
                loc.latitude,
                loc.longitude,
                response.data[i].latitude,
                response.data[i].longitude
              );

              response.data.sort(function (a, b) {
                return a.distance - b.distance;
              });
            }

            this.setState({ hcpData: response.data });
            this.setState({ isLoading: false });
          }, 3000);
        },
        (error) => {
          console.log(error.response.data);
        }
      )
      .catch((error) => {
        console.log(error.response.data);
      });
  }

  getConsultsPatient(userToken) {
    var param = {};
    var data = {
      name: "getConsultsPatient",
      param: param,
      token: JSON.parse(userToken),
    };

    axios({
      url: url_key + "getConsultsPatient",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);

          if (response.data == null) {
            setTimeout(() => {
              this.setState({ hcpData: this.state.hcpData });
              this.setState({ isLoading: false });
            }, 3000);
          } else {
            for (let i = 0; i < response.data.length; i++) {
              //console.log(response.data[i])

              if (response.data[i].stage == "Request sent") {
                //console.log(response.data[i].stage)
                this.setState({ hcpData: response.data[i].hcp });
                this.setState({ arrayholder: response.data[i].hcp }); //hold data for searching
                this.setState({ isLoading: false });
                let hcp_lat;
                let hcp_long;
                for (
                  let index = 0;
                  index < response.data[i].hcp.length;
                  index++
                ) {
                  //console.log(response.data[i].hcp[index]);
                  this.setState({ lats: response.data[i].hcp[index].latitude });
                  this.setState({
                    longs: response.data[i].hcp[index].longitude,
                  });

                  hcp_lat = response.data[i].hcp[index].latitude;
                  hcp_long = response.data[i].hcp[index].longitude;
                }

                //console.log(response.data[i].latitude);

                this.props.navigation.navigate("Map", {
                  con_id: response.data[i].id,
                  user_id: response.data[i].user_id,
                  stage: response.data[i].stage,
                  pat_lat: response.data[i].latitude,
                  pat_lon: response.data[i].longitude,
                  hcp_id: response.data[i].hcp_id,
                  hcp_lat: hcp_lat,
                  hcp_long: hcp_long,
                });
              } else {
                if (response.data[i].stage == "Accepted") {
                  console.log("Accepted");
                  let hcp_lat = 0;
                  let hcp_long = 0;
                  for (
                    let index = 0;
                    index < response.data[i].hcp.length;
                    index++
                  ) {
                    hcp_lat = response.data[i].hcp[index].latitude;
                    hcp_long = response.data[i].hcp[index].longitude;
                  }

                  this.props.navigation.navigate("Map", {
                    con_id: response.data[i].id,
                    user_id: response.data[i].user_id,
                    stage: response.data[i].stage,
                    pat_lat: response.data[i].latitude,
                    pat_lon: response.data[i].longitude,
                    hcp_id: response.data[i].hcp_id,
                    hcp_lat: hcp_lat,
                    hcp_long: hcp_long,
                  });
                } else if (response.data[i].stage == "On the way") {
                  console.log("On the way");
                  let hcp_lat = 0;
                  let hcp_long = 0;
                  for (
                    let index = 0;
                    index < response.data[i].hcp.length;
                    index++
                  ) {
                    hcp_lat = response.data[i].hcp[index].latitude;
                    hcp_long = response.data[i].hcp[index].longitude;
                  }

                  this.props.navigation.navigate("Map", {
                    con_id: response.data[i].id,
                    user_id: response.data[i].user_id,
                    stage: response.data[i].stage,
                    pat_lat: response.data[i].latitude,
                    pat_lon: response.data[i].longitude,
                    hcp_id: response.data[i].hcp_id,
                    hcp_lat: hcp_lat,
                    hcp_long: hcp_long,
                  });
                } else if (response.data[i].stage == "Arrived") {
                  console.log("Arrived");
                  //console.log(response.data[i].id);

                  let hcp_lat = 0;
                  let hcp_long = 0;
                  for (
                    let index = 0;
                    index < response.data[i].hcp.length;
                    index++
                  ) {
                    hcp_lat = response.data[i].hcp[index].latitude;
                    hcp_long = response.data[i].hcp[index].longitude;
                  }

                  this.props.navigation.navigate("Map", {
                    con_id: response.data[i].id,
                    user_id: response.data[i].user_id,
                    stage: response.data[i].stage,
                    pat_lat: response.data[i].latitude,
                    pat_lon: response.data[i].longitude,
                    hcp_id: response.data[i].hcp_id,
                    hcp_lat: hcp_lat,
                    hcp_long: hcp_long,
                  });
                } else if (response.data[i].stage == "Closed") {
                  console.log("Closed");
                  this.setState({ hcpData: response.data[i].hcp });
                  this.setState({ isLoading: false });
                  for (
                    let index = 0;
                    index < response.data[i].hcp.length;
                    index++
                  ) {
                    //console.log(response.data[i])
                    this.setState({
                      lats: response.data[i].hcp[index].latitude,
                    });
                    this.setState({
                      longs: response.data[i].hcp[index].longitude,
                    });
                  }
                  //this.props.navigation.navigate('Invoice',{con_id:response.data[i].id,});

                  let b = response.data[i].id.length;
                  this.setState({ con_id: response.data[i].id });
                  console.log(b);

                  if (b > 0) {
                    this.setModalVisible1(true);
                  }
                  continue;
                } else if (response.data[i].stage == "Rating") {
                  //console.log('Rating')
                  this.setState({ hcpData: response.data[i].hcp });
                  this.setState({ isLoading: false });
                  for (
                    let index = 0;
                    index < response.data[i].hcp.length;
                    index++
                  ) {
                    //console.log(response.data[i])
                    this.setState({
                      lats: response.data[i].hcp[index].latitude,
                    });
                    this.setState({
                      longs: response.data[i].hcp[index].longitude,
                    });
                  }
                } else {
                  console.log("after");
                }
              }
            }
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  searchFilterFunction = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState({ search: val });

    const newData = this.state.hcpData.filter((item) => {
      const itemData = `${item.full_names.toUpperCase()} ${item.address1.toUpperCase()}`;

      const textData = val.toUpperCase();

      return itemData.indexOf(textData) > -1;
    });

    this.setState({ searchData: newData });
  };

  renderHCPsComponent = (hcpData) => (
    <View style={styles.consultationView}>
      <View style={styles.patatientContatiner}>
        <Image
          source={
            !hcpData.item.profile_pic
              ? "https://batcave.healtha.co.za/uploads/assets/avatar.png"
              : { uri: logo_url + "logo/" + hcpData.item.profile_pic }
            /* null ? require("../assets/avatar1.png")
              : { uri: logo_url + "logo/" + hcpData.item.profile_pic }*/
          }
          style={styles.patientImage}
        />
        <View
          style={{
            alignSelf: "flex-start",
            paddingHorizontal: 5,
            paddingVertical: 0,
            borderRadius: 20,
            marginTop: 0,
            marginLeft: 15,
            borderColor: "#fff",
            width: "75%",
            borderWidth: 1,
          }}
        >
          <View style={{ flexDirection: "row" }}>
            <View
              style={{
                width: "50%",
                alignItems: "flex-start",
                alignSelf: "flex-start",
                justifyContent: "flex-start",
              }}
            >
              <Text style={{ fontWeight: "bold" }}>
                {hcpData.item.practice_name}
              </Text>
            </View>
            <View
              style={{
                alignItems: "flex-end",
                alignSelf: "flex-end",
                justifyContent: "flex-end",
              }}
            >
              {
                //let dis = this.state.distance;
                /*this.state.distance.map((myValue,myIndex) => {
                                var newIndexV = (myIndex+1).toString();
                                
                                console.log(myValue.newIndexV);
                                  return(
                                     <TouchableOpacity style={{backgroundColor:colors[myIndex],borderWidth:1,borderColor:'#fff',borderRadius:10,}} key={myValue.newIndexV}><Text style={{fontSize:12,color:'#fff',alignContent:'center',justifyContent:'center',marginHorizontal:5,marginVertical:5,margin:5,}}>{myValue.name}</Text></TouchableOpacity>
                                    
                                   )
                                
                            })
                            <Text style={{fontWeight:'bold',paddingHorizontal:20,marginHorizontal:30,alignContent:"flex-start",alignItems:"flex-start",alignSelf:"flex-start"}}>{this.state.distance} km</Text>
                            */
              }
            </View>
          </View>
          <View style={{ flexDirection: "row", paddingVertical: 5 }}>
            <Text style={{ fontWeight: "normal" }}>
              {hcpData.item.address1 +
                " " +
                hcpData.item.address2 +
                "," +
                hcpData.item.code}
            </Text>
          </View>
          <View style={{ flexDirection: "row", paddingVertical: 10 }}>
            <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate("HCP", {
                  hcp_id: hcpData.item.hcp_id,
                  profile_pic: hcpData.item.profile_pic,
                  user_id: hcpData.item.user_id,
                  mobile: hcpData.item.mobile,
                  address1: hcpData.item.address1,
                  address2: hcpData.item.address2,
                  code: hcpData.item.code,
                  latitude: hcpData.item.latitude,
                  longitude: hcpData.item.longitude,
                  consultation_fee: hcpData.item.consultation_fee,
                  accept_medical_aid: hcpData.item.accept_medical_aid,
                  full_names: hcpData.item.full_names,
                  sym: hcpData.item.sym,
                  sp: hcpData.item.sp,
                })
              }
              style={styles.patientButtons}
            >
              <Text style={{ color: "#fff" }}>View More</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );

  componentDidMount() {
    this.getToken();
    this.getLocationAsync();
    //this.getHCPs();
    this.willFocusSubscription = this.props.navigation.addListener(
      "focus",
      () => {
        this.getToken();
        this.getLocationAsync();
        // this.getHCPs();
      }
    );
  }

  render() {
    const { modalVisible } = this.state;
    const { modalVisible1 } = this.state;

    setTimeout(() => {
      let dis = [];
      dis = this.state.distance;
    }, 3000);

    if (this.state.isLoading) {
      return (
        <View
          style={{
            flex: 1,
            backgroundColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ActivityIndicator size="large" color="#1F3A93" />
        </View>
      );
    }
    return (
      <View style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <TouchableOpacity
            style={{ width: "10%" }}
            onPress={() => this.props.navigation.openDrawer()}
          >
            <Ionicons name={"menu"} color={"#fff"} size={35} />
          </TouchableOpacity>
          <View style={{ width: "70%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#fff",
                }}
              >
                DASHBOARD
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={{ width: "10%" }}
            onPress={() => this.setModalVisible(true)}
          >
            <Ionicons name={"search"} color={"#fff"} size={35} />
          </TouchableOpacity>
          <TouchableOpacity
            style={{ width: "12%" }}
            onPress={() => this.props.navigation.navigate("Profile")}
          >
            <Image
              source={this.state.avatarImg}
              style={{
                width: 30,
                height: 30,
                borderRadius: 15,
                backgroundColor: "#FFF",
                borderColor: "#fff",
                borderWidth: 1,
              }}
            />
          </TouchableOpacity>
        </View>
        <View style={styles.bodyHeader}></View>
        <View
          style={{
            backgroundColor: "#1F3A93",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ paddingTop: 3, paddingBottom: 3 }}
          >
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              <TouchableOpacity
                style={styles.headerItems}
                onPress={() => this.props.navigation.navigate("History")}
              >
                <Icon name={"book"} color={"#1F3A93"} size={25} />
              </TouchableOpacity>
              <Text style={{ fontSize: 16, paddingLeft: 0, color: "#fff" }}>
                History
              </Text>
            </View>
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              {/*<TouchableOpacity style={styles.headerItems}  onPress={() => this.props.navigation.navigate('MyConsultation')}>
                                <Icon  name={Platform.OS === "ios" ? "md-mail-unread" : "md-mail-unread" } color={"#1F3A93"} size={25} />
                                                    </TouchableOpacity>
                                <Text style={{fontSize:14,paddingLeft:0, color:'#fff'}}>My Consultation</Text>*/}
            </View>
            <View
              style={{ alignItems: "center", justifyContent: "center" }}
            ></View>
          </ScrollView>
        </View>
        <View style={styles.bodyContainer}>
          {this.state.isLoading ? (
            <View
              style={{
                flex: 1,
                backgroundColor: "#f5f5f5",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <ActivityIndicator size="large" color="#1F3A93" />
            </View>
          ) : (
            <SafeAreaView>
              <Text
                style={{ fontSize: 20, fontWeight: "normal", color: "#1F3A93" }}
              >
                Health Care Professionals
              </Text>
              <FlatList
                data={this.state.hcpData}
                renderItem={(item) => this.renderHCPsComponent(item)}
                keyExtractor={(item) => item.user_id.toString()}
                nestedScrollEnabled={true}
                refreshing={false}
                onRefresh={() => this.getHCPs(this.state.userToken)}
              />

              <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => {
                  this.setModalVisible(!modalVisible);
                }}
              >
                <View style={styles.centeredView}>
                  <View style={styles.modalView}>
                    <View style={styles.modalHeader}>
                      <View style={styles.searchInputView2}>
                        <TextInput
                          placeholderTextColor={"#000"}
                          placeholder="Search"
                          value={this.state.search}
                          onChangeText={(val) =>
                            this.searchFilterFunction(val, "search")
                          }
                          style={styles.search_input}
                          keyboardAppearance="light"
                        />
                      </View>
                      <TouchableOpacity
                        style={{ backgroundColor: "#1F3A93", borderRadius: 20 }}
                        onPress={() => this.setModalVisible(!modalVisible)}
                      >
                        <Icon name={"close"} color={"#fff"} size={30} />
                      </TouchableOpacity>
                    </View>

                    <SafeAreaView>
                      <FlatList
                        data={this.state.searchData}
                        renderItem={(item) => this.renderHCPsComponent(item)}
                        keyExtractor={(item) => item.user_id.toString()}
                        nestedScrollEnabled={true}
                      />
                    </SafeAreaView>
                  </View>
                </View>
              </Modal>

              <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible1}
                onRequestClose={() => {
                  this.setModalVisible1(!modalVisible1);
                }}
              >
                <View style={styles.centeredView}>
                  <View style={styles.modalView}>
                    <View
                      style={{ alignItems: "center", justifyContent: "center" }}
                    >
                      <Text
                        style={{
                          fontSize: 20,
                          color: "#1F3A93",
                          fontWeight: "bold",
                        }}
                      >
                        Please rate your last consultation
                      </Text>
                    </View>

                    <View style={styles.modalHeader}></View>

                    <SafeAreaView
                      style={{
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      {/* <StarRating
                        disabled={false}
                        emptyStar={"ios-star-outline"}
                        fullStar={"ios-star"}
                        halfStar={"ios-star-half"}
                        iconSet={"Ionicons"}
                        maxStars={5}
                        rating={this.state.starCount}
                        selectedStar={(rating) =>
                          this.onStarRatingPress(rating)
                        }
                        fullStarColor={"#1F3A93"}
                      />*/}

                      <RatingInput
                        rating={this.state.starCount}
                        setRating={(rating) => this.onStarRatingPress(rating)}
                        size={50}
                        maxStars={5}
                        bordered={false}
                      />

                      <View
                        style={{
                          alignItems: "center",
                          justifyContent: "center",
                          marginTop: 10,
                        }}
                      >
                        <TouchableOpacity
                          style={styles.loginBtn}
                          onPress={() => this.submitRating()}
                        >
                          <Text style={styles.loginText}>Close</Text>
                        </TouchableOpacity>
                      </View>
                    </SafeAreaView>
                  </View>
                </View>
              </Modal>
            </SafeAreaView>
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
    backgroundColor: "#1F3A93",
    borderRadius: 10,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
    backgroundColor: "#fff",
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
    marginBottom: 200,
  },
  productsContainer: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#302121",
    borderRadius: 10,
  },
  totalContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 15,
    borderRadius: 10,
    backgroundColor: "#302121",
  },
  checkoutContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productContent: {
    marginTop: 10,
    marginBottom: 10,
  },
  consultationView: {
    marginVertical: 5,
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  patatientContatiner: {
    flexDirection: "row",
    margin: 0,
  },
  patientImage: {
    height: 50,
    alignSelf: "center",
    width: 50,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    marginLeft: 8,
  },
  showMore: {
    marginLeft: 8,
  },
  showMoreContent: {
    fontWeight: "bold",
  },
  patientButtons: {
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "#1F3A93",
    marginHorizontal: 5,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 15,
  },
  headerItems: {
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center",
    flexDirection: "row",
    backgroundColor: "#fff",
    marginHorizontal: 20,
    borderRadius: 25,
    paddingVertical: 5,
    paddingHorizontal: 5,
    width: 40,
    height: 40,
  },
  modalContent: {
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 4,
    borderColor: "rgba(0, 0, 0, 0.1)",
    margin: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    marginTop: 10,
    margin: 5,
  },
  modalView: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  searchInputView2: {
    flexDirection: "row",
    width: "90%",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#1F3A93",
    borderColor: "#302121",
    paddingRight: 10,
  },
  search_input: {
    color: "#000",
    fontSize: 14,
    paddingLeft: 5,
    flex: 1,
    fontFamily: "normal",
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
});
