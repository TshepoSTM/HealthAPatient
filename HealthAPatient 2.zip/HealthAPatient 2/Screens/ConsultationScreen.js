import "react-native-gesture-handler";
import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  SafeAreaView,
  TextInput,
} from "react-native";
import { Image } from "expo-image";
import Icon from "react-native-vector-icons/Ionicons";
import axios from "axios";
import { url_key, myApiKey, auth_key_fcm } from "../config/url_key";

export default class ConsultationScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      bank_name: "",
      acc_holder: "",
      acc_type: "",
      acc_number: "",
      branch_code: "",
      card_number: "",
      name_on_card: "",
      expiry_date: "",
      security_code: "",
      errorBankName: "",
      errorAccHolder: "",
      errorAcctype: "",
      errorAccNumber: "",
      errorBranchCode: "",
      errorCardNumber: "",
      errorNameCard: "",
      errorExpiryDate: "",
      errorSecCode: "",
    };
  }
  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorBankName: "" });
    this.setState({ errorAccHolder: "" });
    this.setState({ errorAcctype: "" });
    this.setState({ errorBankName: "" });
    this.setState({ errorBranchCode: "" });
    this.setState({ errorCardNumber: "" });
    this.setState({ errorNameCard: "" });
    this.setState({ errorExpiryDate: "" });
    this.setState({ errorSecCode: "" });
  };

  submitBankDetails() {
    if (this.state.bank_name == "") {
      this.setState({ errorBankName: "Enter bank name" });
    }
    if (this.state.acc_holder == "") {
      this.setState({ errorAccHolder: "Enter account holder" });
    }
    if (this.state.acc_type == "") {
      this.setState({ errorAcctype: "Enter account type" });
    }
    if (this.state.acc_number == "") {
      this.setState({ errorAccNumber: "Enter account number" });
    }
    if (this.state.branch_code == "") {
      this.setState({ errorBranchCode: "Enter branch code" });
    }
    if (this.state.card_number == "") {
      this.setState({ errorCardNumber: "Enter card number" });
    }
    if (this.state.name_on_card == "") {
      this.setState({ errorNameCard: "Enter name on card" });
    }
    if (this.state.expiry_date == "") {
      this.setState({ errorExpiryDate: "Enter expiry date" });
    }
    if (this.state.security_code == "") {
      this.setState({ errorSecCode: "Enter security code" });
    }
    if (
      this.state.bank_name != "" &&
      this.state.acc_number != "" &&
      this.state.acc_holder != "" &&
      this.state.acc_type != "" &&
      this.state.branch_code != "" &&
      this.state.card_number &&
      this.state.name_on_card != "" &&
      this.state.expiry_date != "" &&
      this.state.security_code
    ) {
      return;
      var param = {
        bank_name: this.state.bank_name,
        acc_holder: this.state.acc_holder,
        acc_type: this.state.acc_type,
        acc_number: this.state.acc_number,
        branch_code: this.state.branch_code,
        fri_to: this.state.card_number,
        name_on_card: this.state.name_on_card,
        expiry_date: this.state.expiry_date,
        security_code: this.state.security_code,
      };

      var data = { name: "getSymptoms", param: param };

      axios({
        url: "http://batcave.healtha.co.za/Administration/getSymptoms",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            //console.log(JSON.stringify(response.data));
          },
          (error) => {
            console.log(error);
          }
        )
        .catch((error) => {
          console.log(error);
        });
    }
  }

  componentDidMount() {}
  render() {
    return (
      <View style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity
              onPress={() => this.props.navigation.push("Home")}
            >
              <Icon name={"arrow-back"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                BANKING DETAILS
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity></TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            <SafeAreaView>
              <View style={styles.modalView}>
                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "bold",
                    color: "#1F3A93",
                    marginBottom: 5,
                  }}
                >
                  Banking Information
                </Text>
                <View style={styles.bankInfo}>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Bank Name"}
                      autoCapitalize="none"
                      value={this.state.bank_name}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "bank_name")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorBankName}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Account Holder"}
                      autoCapitalize="none"
                      value={this.state.acc_holder}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "acc_holder")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorAccHolder}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Account Type"}
                      autoCapitalize="none"
                      value={this.state.acc_type}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "acc_type")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorAcctype}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Account Number"}
                      autoCapitalize="none"
                      value={this.state.acc_number}
                      maxLength={13}
                      keyboardType={"numeric"}
                      numeric
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "acc_number")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorAccNumber}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Branch Code"}
                      autoCapitalize="none"
                      value={this.state.branch_code}
                      maxLength={10}
                      keyboardType={"numeric"}
                      numeric
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "branch_code")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorBranchCode}
                    </Text>
                  </View>
                </View>
              </View>
              <View style={[styles.modalView, { marginVertical: 15 }]}>
                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "bold",
                    color: "#1F3A93",
                    marginBottom: 5,
                  }}
                >
                  Card Details
                </Text>
                <View style={styles.bankInfo}>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Card Number"}
                      autoCapitalize="none"
                      value={this.state.card_number}
                      keyboardType={"numeric"}
                      numeric
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "card_number")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorCardNumber}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Name On Card"}
                      autoCapitalize="none"
                      value={this.state.name_on_card}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "name_on_card")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorNameCard}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Expiry Date"}
                      autoCapitalize="none"
                      value={this.state.expiry_date}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "expiry_date")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorExpiryDate}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Security Code"}
                      autoCapitalize="none"
                      value={this.state.security_code}
                      keyboardType={"numeric"}
                      numeric
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "security_code")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorSecCode}
                    </Text>
                  </View>
                  <Text style={styles.text_footer}></Text>
                </View>
              </View>
              <View
                style={{
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 5,
                }}
              >
                <TouchableOpacity
                  style={styles.loginBtn}
                  onPress={() => this.submitBankDetails()}
                >
                  <Text style={styles.loginText}>Submit</Text>
                </TouchableOpacity>
              </View>
            </SafeAreaView>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 0,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  bankInfo: {
    marginBottom: 10,
  },
  modalContent: {
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 4,
    borderColor: "rgba(0, 0, 0, 0.1)",
    margin: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
  },
  modalView: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 1,
  },
  action: {
    flexDirection: "row",
    marginTop: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#d9d4d9",
    paddingBottom: 0,
  },
  text_input: {
    flex: 1,
    paddingLeft: 10,
    color: "#000",
    fontSize: 14,
  },
  text_footer: {
    fontSize: 10,
    color: "black",
  },
  texterror: {
    fontSize: 12,
  },
});
