import "react-native-gesture-handler";
import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TouchableHighlight,
  SafeAreaView,
  FlatList,
  Alert,
  ImageBackground,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Image } from "expo-image";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Icon from "react-native-vector-icons/Ionicons";
import axios from "axios";
import { url_key, myApiKey } from "../config/url_key";

export default class InvoiceScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userToken: "",
      data: [],
      invoiceData: {},
      practice_name: "",
    };
  }

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });
      //console.log('user token',userToken);
      this.getConsultInvoice(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  getConsultInvoice(userToken) {
    var data = {
      name: "getConsultInvoice",
      param: { con_id: this.props.route.params.con_id },
      token: JSON.parse(userToken),
    };

    //console.log(data)

    axios({
      url: url_key + "getConsultInvoice",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          this.setState({ invoiceData: response.data });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  componentDidMount() {
    this.getToken();
    this.willFocusSubscription = this.props.navigation.addListener(
      "focus",
      () => {
        //this.getToken();
      }
    );
  }
  render() {
    var p_status;
    if (this.props.route.params.paid == 0) {
      p_status = "UNPAID";
    } else {
      p_status = "PAID";
    }

    return (
      <View style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("Home")}
            >
              <Icon name={"arrow-back"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                Invoice
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity></TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            <SafeAreaView>
              <View style={styles.consultationView}>
                <View style={styles.patatientContatiner}>
                  <Image
                    source={
                      "https://batcave.healtha.co.za/uploads/assets/avatar1.png"
                    }
                    style={styles.patientImage}
                  />
                  <View
                    style={{
                      alignSelf: "flex-start",
                      paddingHorizontal: 5,
                      paddingVertical: 0,
                      borderRadius: 20,
                      marginTop: 0,
                      marginLeft: 10,
                      borderColor: "#fff",
                      borderWidth: 1,
                    }}
                  >
                    <View style={{ flexDirection: "row", width: "100%" }}>
                      <View style={{ width: "40%" }}>
                        <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                          {this.state.invoiceData.practice_name}
                        </Text>
                      </View>
                      <View style={{ paddingHorizontal: 0, width: "60%" }}>
                        <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                          {this.state.invoiceData.address1}
                        </Text>
                      </View>
                    </View>
                    <View style={{ flexDirection: "row", width: "100%" }}>
                      <View style={{ width: "40%" }}>
                        <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                          {this.state.invoiceData.mobile}
                        </Text>
                      </View>
                      <View style={{ paddingHorizontal: 0, width: "60%" }}>
                        <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                          {this.state.invoiceData.address2}
                        </Text>
                      </View>
                    </View>
                    <View style={{ flexDirection: "row", width: "100%" }}>
                      <View style={{ width: "40%" }}>
                        <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                          {this.state.invoiceData.email}
                        </Text>
                      </View>
                      <View style={{ paddingHorizontal: 0, width: "60%" }}>
                        <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                          {this.state.invoiceData.code}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 5 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Bill To
                      </Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "40%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Invoice Number
                      </Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "70%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Invoice Total
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 1 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "35%" }}>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        Tshepo Mathatho
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        No 3 Makgabe Village, Plokwane,0700
                      </Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "40%" }}>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.invno}
                      </Text>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Date
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.date}
                      </Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "50%" }}>
                      <View style={{ flexDirection: "row" }}>
                        <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                          R{this.state.invoiceData.amount}
                        </Text>
                        <Text
                          style={{
                            fontWeight: "bold",
                            color: "red",
                            fontSize: 12,
                            paddingHorizontal: 10,
                          }}
                        >
                          {p_status}
                        </Text>
                      </View>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Due Date
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.duedate}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 5 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "75%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Description
                      </Text>
                    </View>

                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Amount
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 5 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "75%" }}>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        Tshepo Mathatho
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        No 3 Makgabe Village, Plokwane,0700
                      </Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        R{this.state.invoiceData.amount}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 5 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "75%" }}></View>
                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Sub Total
                      </Text>
                    </View>
                  </View>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "75%" }}></View>
                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        R{this.state.invoiceData.amount}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 5 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "75%" }}></View>
                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Total
                      </Text>
                    </View>
                  </View>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "75%" }}>
                      <Text
                        style={{ fontWeight: "normal", fontSize: 12 }}
                      ></Text>
                      <Text
                        style={{ fontWeight: "normal", fontSize: 12 }}
                      ></Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        R{this.state.invoiceData.amount}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{ paddingVertical: 5 }}>
                  <View style={{ flexDirection: "row", width: "100%" }}>
                    <View style={{ width: "35%" }}>
                      <Text style={{ fontWeight: "bold", fontSize: 12 }}>
                        Bank Details
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        Bank Name
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        Branch Number
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        Account Holder
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        Account Number
                      </Text>
                    </View>
                    <View style={{ paddingHorizontal: 0, width: "35%" }}>
                      <Text
                        style={{ fontWeight: "normal", fontSize: 12 }}
                      ></Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.bankName}
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.branchCode}
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.accHolder}
                      </Text>
                      <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                        {this.state.invoiceData.accNo}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </SafeAreaView>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 15,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  productsContainer: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#302121",
    borderRadius: 10,
  },
  totalContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 15,
    borderRadius: 10,
    backgroundColor: "#302121",
  },
  checkoutContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productContent: {
    marginTop: 10,
    marginBottom: 10,
  },
  consultationView: {
    marginVertical: 5,
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  patatientContatiner: {
    flexDirection: "row",
    margin: 0,
    width: "100%",
    alignItems: "center",
    alignContent: "center",
  },
  patientImage: {
    height: 60,
    width: 60,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    marginLeft: 0,
  },
  addressContent: {
    width: "100%",
  },
  patientButtons: {
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "#1F3A93",
    marginHorizontal: 5,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 15,
  },
});
