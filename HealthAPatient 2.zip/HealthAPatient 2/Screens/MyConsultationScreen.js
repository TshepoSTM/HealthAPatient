import "react-native-gesture-handler";
import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from "react-native";
import { Image } from "expo-image";
import Icon from "react-native-vector-icons/Ionicons";
import axios from "axios";

export default class MyConsultationScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
    };
  }

  getMyHistory() {
    return;
    var data = { name: "getSymptoms", param: {} };
    axios({
      url: "http://batcave.healtha.co.za/Administration/getSymptoms",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(JSON.stringify(response.data));
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  componentDidMount() {}
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("Home")}
            >
              <Icon name={"arrow-back"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                My Consultation
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity>
              <Icon name={"search"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            <SafeAreaView>
              <View style={styles.consultationView}>
                <View style={styles.patatientContatiner}>
                  <Image
                    source={
                      "https://batcave.healtha.co.za/uploads/assets/avatar1.png"
                    }
                    style={styles.patientImage}
                  />
                  <View
                    style={{
                      alignSelf: "flex-start",
                      paddingHorizontal: 5,
                      paddingVertical: 0,
                      borderRadius: 20,
                      marginTop: 0,
                      marginLeft: 10,
                      borderColor: "#fff",
                      borderWidth: 1,
                    }}
                  >
                    <View style={{ flexDirection: "row" }}>
                      <Text style={{ fontWeight: "bold" }}>Makwa Masilela</Text>
                      <Text
                        style={{
                          fontWeight: "bold",
                          paddingHorizontal: 0,
                          marginHorizontal: 50,
                          alignItems: "flex-end",
                          alignSelf: "flex-end",
                        }}
                      >
                        2 km
                      </Text>
                    </View>
                    <View style={{ flexDirection: "row", paddingVertical: 5 }}>
                      <Text style={{ fontWeight: "normal" }}>
                        No 49 Market Street,Preotria
                      </Text>
                    </View>
                    <View style={{ flexDirection: "row", paddingVertical: 10 }}>
                      <TouchableOpacity></TouchableOpacity>
                      <TouchableOpacity
                        onPress={() =>
                          this.props.navigation.navigate("PatientDetail")
                        }
                        style={styles.patientButtons}
                      >
                        <Text style={{ color: "#fff" }}>View More</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => this.props.navigation.navigate("Chat")}
                        style={styles.patientButtons}
                      >
                        <Icon
                          name={
                            Platform.OS === "ios"
                              ? "ios-chatbox-ellipses"
                              : "md-chatbox-ellipses"
                          }
                          color={"#fff"}
                          size={20}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
              <View style={styles.consultationView}>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
              </View>
              <View style={styles.consultationView}>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
                <Text>Patient name</Text>
              </View>
            </SafeAreaView>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  productsContainer: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#302121",
    borderRadius: 10,
  },
  totalContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 15,
    borderRadius: 10,
    backgroundColor: "#302121",
  },
  checkoutContent: {
    flexDirection: "row",
    marginHorizontal: 0,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productContent: {
    marginTop: 10,
    marginBottom: 10,
  },
  consultationView: {
    marginVertical: 5,
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  patatientContatiner: {
    flexDirection: "row",
    margin: 0,
  },
  patientImage: {
    height: 80,
    alignSelf: "center",
    width: 80,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    marginLeft: 8,
  },
  patientButtons: {
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "#1F3A93",
    marginHorizontal: 5,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 15,
  },
});
