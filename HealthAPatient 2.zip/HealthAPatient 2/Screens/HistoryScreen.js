import "react-native-gesture-handler";
import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  FlatList,
  Modal,
  TextInput,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import Icon from "react-native-vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { url_key, myApiKey } from "../config/url_key";

export default class HistoryScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      searchData: [],
      modalVisible: false,
      isContent: true,
      isLoading: true,
    };
  }

  searchFilterFunction = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState({ search: val });

    const newData = this.state.data.filter((item) => {
      const itemData = `${item.contactPerson.toUpperCase()} ${item.practice_name.toUpperCase()}`;

      const textData = val.toUpperCase();

      return itemData.indexOf(textData) > -1;
    });

    this.setState({ searchData: newData });
  };

  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
    this.setState({ searchData: [] });
  };

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });
      this.getMyHistory(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  getMyHistory(userToken) {
    var param = {};
    var data = {
      name: "getConsultHistory",
      param: param,
      token: JSON.parse(userToken),
    };

    axios({
      url: url_key + "getConsultHistory",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          this.setState({ data: response.data });
          this.setState({ isLoading: false });
          this.setState({ isContent: false });
        },
        (error) => {
          console.log(error.response.data);
        }
      )
      .catch((error) => {
        console.log(error.response.data);
      });
  }

  renderHistoryComponent = (data) => (
    <View style={styles.consultationView}>
      <TouchableOpacity style={styles.patatientContatiner}>
        <Image
          source={"https://batcave.healtha.co.za/uploads/assets/avatar1.png"}
          style={styles.patientImage}
        />
        <View
          style={{
            alignSelf: "flex-start",
            paddingHorizontal: 5,
            paddingVertical: 0,
            borderRadius: 20,
            marginTop: 0,
            marginLeft: 10,
            borderColor: "#fff",
            borderWidth: 1,
          }}
        >
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                Full names
              </Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                {data.item.contactPerson}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                Practice name
              </Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                {data.item.practice_name}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", width: "100%" }}>
            <View style={{ width: "32%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>Date</Text>
            </View>
            <View style={{ paddingHorizontal: 0, width: "70%" }}>
              <Text style={{ fontWeight: "normal", fontSize: 12 }}>
                {data.item.date}
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );

  componentDidMount() {
    this.getToken();
  }
  render() {
    const { modalVisible } = this.state;

    if (this.state.isLoading) {
      return (
        <View
          style={{
            flex: 1,
            backgroundColor: "#fff",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ActivityIndicator size="large" color="#1F3A93" />
        </View>
      );
    }
    return (
      <View style={styles.container}>
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("Home")}
            >
              <Icon name={"arrow-back"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                History
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity onPress={() => this.setModalVisible(true)}>
              <Icon name={"search"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            {this.state.isContent ? (
              <View style={styles.hcpStatus}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 18, color: "#1F3A93" }}
                >
                  No Records
                </Text>
              </View>
            ) : (
              <SafeAreaView>
                <FlatList
                  data={this.state.data}
                  renderItem={(item) => this.renderHistoryComponent(item)}
                  keyExtractor={(item) => item.id.toString()}
                  nestedScrollEnabled={true}
                />
              </SafeAreaView>
            )}

            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible}
              onRequestClose={() => {
                this.setModalVisible(!modalVisible);
              }}
            >
              <View style={styles.centeredView}>
                <View style={styles.modalView}>
                  <View style={styles.modalHeader}>
                    <View style={styles.searchInputView2}>
                      <TextInput
                        placeholderTextColor={"#000"}
                        placeholder="Search"
                        value={this.state.search}
                        onChangeText={(val) =>
                          this.searchFilterFunction(val, "search")
                        }
                        style={styles.search_input}
                        keyboardAppearance="light"
                      />
                    </View>
                    <TouchableOpacity
                      style={{ backgroundColor: "#1F3A93", borderRadius: 20 }}
                      onPress={() => this.setModalVisible(!modalVisible)}
                    >
                      <Icon name={"close"} color={"#fff"} size={30} />
                    </TouchableOpacity>
                  </View>

                  <SafeAreaView>
                    <FlatList
                      data={this.state.searchData}
                      renderItem={(item) => this.renderHistoryComponent(item)}
                      keyExtractor={(item) => item.id.toString()}
                      nestedScrollEnabled={true}
                    />
                  </SafeAreaView>
                </View>
              </View>
            </Modal>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 0,
    marginTop: 0,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  consultationView: {
    marginVertical: 5,
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
  patatientContatiner: {
    flexDirection: "row",
    margin: 0,
  },
  patientImage: {
    height: 60,
    alignSelf: "center",
    width: 60,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    marginLeft: 5,
  },
  patientButtons: {
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "#1F3A93",
    marginHorizontal: 5,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 15,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
    backgroundColor: "#fff",
  },
  modalContent: {
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 4,
    borderColor: "rgba(0, 0, 0, 0.1)",
    margin: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    marginTop: 10,
    margin: 5,
  },
  modalView: {
    margin: 0,
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  searchInputView2: {
    flexDirection: "row",
    width: "90%",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#1F3A93",
    borderColor: "#302121",
    paddingRight: 10,
  },
  search_input: {
    color: "#000",
    fontSize: 14,
    paddingLeft: 5,
    flex: 1,
    fontFamily: "normal",
  },
  hcpStatus: {
    marginVertical: 5,
    margin: 0,
    alignItems: "center",
    alignContent: "center",
    backgroundColor: "#fff",
    borderRadius: 5,
    padding: 5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 2,
  },
});
