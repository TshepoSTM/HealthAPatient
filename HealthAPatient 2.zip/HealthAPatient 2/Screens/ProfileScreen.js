import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import Icon from "react-native-vector-icons/Ionicons";
import SelectDropdown from "react-native-select-dropdown";
import { MultiSelect } from "react-native-element-dropdown";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { url_key, myApiKey, pic_url, logo_url } from "../config/url_key";
import * as DocumentPicker from "expo-document-picker";

export default class ProfileScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstname: "",
      surname: "",
      role: "",
      adr1: "",
      adr2: "",
      province: "",
      provinces: [],
      selectedProvince: "",
      code: "",
      idNumber: "",
      cellphone: "",
      email: "",
      password: "",
      userToken: "",
      confpassword: "",
      image: "",
      imageName: "",
      isLoading: true,
      avatarImg: null ? { uri: null } : require("../assets/avatar.png"),
      errorMessage: "",
      errorfirstname: "",
      errorSurname: "",
      errorIdNumber: "",
      errorEmail: "",
      errorCellphone: "",
      errorPassword: "",
      errorConfpassword: "",
      errorAdr1: "",
      errorAdr2: "",
      errorProvince: "",
      errorCode: "",
      cardNumber: "",
      errorMedicalAidNo: "",
      medSchemeData: [],
      selectedMedSchems: [],
      showMedNum: true,
    };
  }
  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorfirstname: "" });
    this.setState({ errorSurname: "" });
    this.setState({ errorAdr1: "" });
    this.setState({ errorAdr2: "" });
    this.setState({ errorProvince: "" });
    this.setState({ errorCode: "" });
    this.setState({ errorIdNumber: "" });
    this.setState({ errorCellphone: "" });
    this.setState({ errorEmail: "" });
    this.setState({ errorPassword: "" });
  };
  validateEmail = (email) => {
    //console.log(email);
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,6})+$/;
    if (reg.test(email) === false) {
      //console.log("Email is Not Correct");
      this.setState({ errorEmail: "Your email is Invalid " });
      this.setState({ email: email });
      return false;
    } else {
      this.setState({ email: email });
      console.log("Email is Correct");
      this.setState({ errorEmail: "Email is correct" });
    }
  };

  getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      this.setState({ userToken: userToken });
      //console.log("user token", userToken);
      this.getUser(userToken);
      this.getMedAidDetails(userToken);
    } catch (error) {
      console.log(error);
    }
  };

  pickDocument = async () => {
    let result = await DocumentPicker.getDocumentAsync({
      type: "*/*",
      copyToCacheDirectory: true,
    }).then((response) => {
      //console.log(response);
      if (response.canceled == true) {
        return;
      } else {
        //console.log(response.assets[0]);

        let { name, size, uri } = response.assets[0];
        let nameParts = name.split(".");
        let fileType = nameParts[nameParts.length - 1];

        var fileToUpload = {
          name: name,
          size: size,
          uri: uri,
          type: "application/" + fileType,
        };
        //console.log(fileToUpload, "...............file");
        this.postDocument(fileToUpload);

        this.setState({ image: fileToUpload });
        this.setState({ imageName: fileToUpload.name });
        this.setState({ errorMessage: "" });
      }
    });
    //console.log(this.state.logo);
  };

  postDocument = (file) => {
    const formData = new FormData();
    formData.append("image", file);
    formData.append("token", JSON.parse(this.state.userToken));

    //console.log("formData" + formData);
    axios({
      url: pic_url + "UpdateUserImage",
      method: "POST",
      data: formData,
      headers: {
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          if (response.data == true) {
            this.getUser(this.state.userToken);
          }
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  };

  UpdateProfile() {
    if (this.state.firstname == "") {
      this.setState({ errorfirstname: "Enter first name" });
    }
    if (this.state.surname == "") {
      this.setState({ errorSurname: "Enter surname" });
    }
    if (this.state.adr1 == "") {
      this.setState({ errorAdr1: "Enter Address 1" });
    }
    if (this.state.adr2 == "") {
      this.setState({ errorAdr2: "Enter Address 2" });
    }
    if (this.state.selectedProvince == "") {
      this.setState({ errorProvince: "Enter Province" });
    }
    if (this.state.code == "") {
      this.setState({ errorCode: "Enter Code" });
    }
    if (this.state.idNumber == "" || this.state.idNumber.length != 13) {
      this.setState({ errorIdNumber: "Enter Valid ID" });
    }
    if (this.state.cellphone == "" || this.state.cellphone.length != 10) {
      this.setState({ errorCellphone: "Enter cellphone" });
    }
    if (this.state.email == "") {
      this.setState({ errorEmail: "Enter email" });
    }

    if (
      this.state.firstname != "" &&
      this.state.surname != "" &&
      this.state.cellphone != "" &&
      this.state.idNumber != "" &&
      this.state.email != ""
    ) {
      var param = {
        firstname: this.state.firstname,
        lastname: this.state.surname,
        adr1: this.state.adr1,
        adr2: this.state.adr2,
        province: this.state.selectedProvince,
        code: this.state.code,
        mobile: this.state.cellphone,
        idno: this.state.idNumber,
        email: this.state.email,
        role: this.state.role,
        cardNumber: this.state.cardNumber,
        medicalAidIDs: this.state.selectedMedSchems.toString(),
      };

      var data = {
        name: "UpdateUser",
        param: param,
        token: JSON.parse(this.state.userToken),
      };

      console.log(data);

      axios({
        url: url_key + "UpdateUser",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            //console.log(response.data);
            if (response.data == true) {
              this.getUser(this.state.userToken);
            }
          },
          (error) => {
            console.log(error.response.data);
          }
        )
        .catch((error) => {
          console.log(error.response.data);
        });
    }
  }

  onselectedMedSchemsChange = (selectedMedSchems) => {
    this.setState({ selectedMedSchems });

    for (let i = 0; i < selectedMedSchems.length; i++) {
      console.log(selectedMedSchems[i]);

      if (selectedMedSchems[i] == 1) {
        this.setState({ showMedNum: false });
      } else {
        this.setState({ showMedNum: true });
      }
    }
  };

  getMedSchemes() {
    var data = { name: "getMedSchemes", param: {} };
    axios({
      url: url_key + "getMedSchemes",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          this.setState({ medSchemeData: response.data });
          //this.setState({isLoading:false})
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getUser(userToken) {
    var param = {};
    var data = { name: "getUser", param: param, token: JSON.parse(userToken) };

    //console.log(data);
    axios({
      url: url_key + "getUser",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          this.setState({ firstname: response.data.first_name });
          this.setState({
            surname: response.data.last_name,
            adr1: response.data.address1,
            adr2: response.data.address2,
            code: response.data.code,
            idNumber: response.data.idno,
            email: response.data.email,
            role: response.data.role,
            cellphone: response.data.mobile,
            province: response.data.province,
          });

          if (response.data.image == null || response.data.image == "") {
            this.setState({
              logo: "https://batcave.healtha.co.za/uploads/assets/avatar1.png",
            });
          } else {
            this.setState({
              logo: { uri: logo_url + "logo/" + response.data.image },
            });
            this.setState({
              avatarImg: { uri: logo_url + "logo/" + response.data.image },
            });
          }

          this.setState({ isLoading: false });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  getMedAidDetails(userToken) {
    var param = {};
    var data = {
      name: "getMedAidDetails",
      param: param,
      token: JSON.parse(userToken),
    };

    //console.log(data);
    axios({
      url: url_key + "getMedAidDetails",
      method: "POST",
      data: data,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then(
        (response) => {
          //console.log(response.data);
          if (response.data == null) {
          } else {
            let med_aidIDs = response.data.medicalAidIDs.split(",");
            this.setState({
              selectedMedSchems: med_aidIDs,
              cardNumber: response.data.cardNumber,
            });
          }

          this.setState({ isLoading: false });
        },
        (error) => {
          console.log(error);
        }
      )
      .catch((error) => {
        console.log(error);
      });
  }

  componentDidMount() {
    this.getToken();
    this.getMedSchemes();
    this.willFocusSubscription = this.props.navigation.addListener(
      "focus",
      () => {
        this.getToken();
      }
    );
  }

  render() {
    const province = [
      "Limpopo",
      "Gauteng",
      "North West",
      "Mpumalanga",
      "Free State",
      "Northen Cape",
      "Eastern Cape",
      "Western Cape",
      "Kwa Zulu Natal",
    ];
    const { selectedProvince } = this.state;
    const { selectedMedSchems } = this.state;

    return (
      <View style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("Home")}
            >
              <Icon name={"arrow-back"} color={"#1F3A93"} size={35} />
            </TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            >
              <Text
                style={{
                  paddingHorizontal: 10,
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#1F3A93",
                }}
              >
                My Profile
              </Text>
            </View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity>
              <Image
                source={
                  "https://batcave.healtha.co.za/uploads/assets/avatar.png"
                }
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 15,
                  backgroundColor: "#1F3A93",
                  borderColor: "#1F3A93",
                }}
              />
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            {this.state.isLoading ? (
              <View
                style={{
                  flex: 1,
                  backgroundColor: "#fff",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <ActivityIndicator size="large" color="#1F3A93" />
              </View>
            ) : (
              <View>
                <View style={{ flexDirection: "row" }}>
                  <Image
                    source={this.state.logo}
                    style={{
                      width: 100,
                      height: 100,
                      borderRadius: 50,
                      backgroundColor: "#1F3A93",
                    }}
                  />
                  <TouchableOpacity
                    onPress={() => this.pickDocument()}
                    style={{
                      backgroundColor: "#1F3A93",
                      marginTop: 70,
                      height: 28,
                      borderRadius: 5,
                    }}
                  >
                    <Text style={{ color: "#fff", margin: 3 }}>Change</Text>
                  </TouchableOpacity>
                </View>
                <View style={{ flexDirection: "row", marginTop: 5 }}>
                  <TextInput
                    style={styles.textInput}
                    placeholder="First Name"
                    autoCapitalize="none"
                    value={this.state.firstname}
                    onChangeText={(val) =>
                      this.updateInputsVal(val, "firstname")
                    }
                  />
                  <TextInput
                    style={styles.textInput}
                    placeholder="Surname"
                    autoCapitalize="none"
                    value={this.state.surname}
                    onChangeText={(val) => this.updateInputsVal(val, "surname")}
                  />
                </View>
                <View style={{ flexDirection: "row", marginTop: 0 }}>
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorfirstname}
                  </Text>
                  <Text
                    style={[
                      styles.texterror,
                      { color: "#1F3A93", paddingLeft: 70 },
                    ]}
                  >
                    {this.state.errorSurname}
                  </Text>
                </View>

                <View style={{ flexDirection: "row", marginTop: 0 }}>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Address 1"
                    autoCapitalize="none"
                    value={this.state.adr1}
                    onChangeText={(val) => this.updateInputsVal(val, "adr1")}
                  />
                  <TextInput
                    style={styles.textInput}
                    placeholder="Address 2"
                    autoCapitalize="none"
                    value={this.state.adr2}
                    onChangeText={(val) => this.updateInputsVal(val, "adr2")}
                  />
                </View>
                <View style={{ flexDirection: "row", marginTop: 0 }}>
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorAdr1}
                  </Text>
                  <Text
                    style={[
                      styles.texterror,
                      { color: "#1F3A93", paddingHorizontal: 70 },
                    ]}
                  >
                    {this.state.errorAdr2}
                  </Text>
                </View>

                <View style={{ flexDirection: "row", marginTop: 0 }}>
                  <SelectDropdown
                    data={province}
                    onSelect={(selectedItem, index) => {
                      console.log(selectedItem, index);
                      this.setState({ selectedProvince: selectedItem });
                    }}
                    renderButton={(selectedItem, isOpened) => {
                      return (
                        <View style={styles.dropdownButtonStyle}>
                          <Text style={styles.dropdownButtonTxtStyle}>
                            {(selectedItem && selectedItem) ||
                              "Select Province"}
                          </Text>
                        </View>
                      );
                    }}
                    renderItem={(item, index, isSelected) => {
                      return (
                        <View
                          style={{
                            ...styles.dropdownItemStyle,
                            ...(isSelected && { backgroundColor: "#fff" }),
                          }}
                        >
                          <Text style={styles.dropdownItemTxtStyle}>
                            {item}
                          </Text>
                        </View>
                      );
                    }}
                    showsVerticalScrollIndicator={false}
                    dropdownStyle={styles.dropdownMenuStyle}
                  />
                  <TextInput
                    style={styles.textInput}
                    placeholder="Code"
                    autoCapitalize="none"
                    value={this.state.code}
                    onChangeText={(val) => this.updateInputsVal(val, "code")}
                  />
                </View>
                <View style={{ flexDirection: "row", marginTop: 0 }}>
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorProvince}
                  </Text>
                  <Text
                    style={[
                      styles.texterror,
                      { color: "#1F3A93", paddingHorizontal: 80 },
                    ]}
                  >
                    {this.state.errorCode}
                  </Text>
                </View>
                {/* <MultiSelect
                items={this.state.medSchemeData}
                uniqueKey="id"
                ref={(component) => {
                  this.multiSelect = component;
                }}
                onSelectedItemsChange={this.onselectedMedSchemsChange}
                selectedItems={selectedMedSchems}
                selectText="Choose medical aid"
                searchInputPlaceholderText="Search Items..."
                onChangeInput={(text) => console.log(text)}
                tagRemoveIconColor="#CCC"
                tagBorderColor="#CCC"
                tagTextColor="#CCC"
                selectedItemTextColor="#CCC"
                selectedItemIconColor="#CCC"
                itemTextColor="#000"
                displayKey="name"
                searchInputStyle={{ color: "#CCC" }}
                submitButtonColor="#1F3A93"
                submitButtonText="Confirm"
                styleMainWrapper={{ margin: 5, paddingVertical: 0 }}
                styleDropdownMenu={{ margin: 5 }}
              />*/}

                <MultiSelect
                  style={styles.dropdown}
                  placeholderStyle={styles.placeholderStyle}
                  selectedTextStyle={styles.selectedTextStyle}
                  inputSearchStyle={styles.inputSearchStyle}
                  iconStyle={styles.iconStyle}
                  search
                  data={this.state.medSchemeData}
                  labelField="name"
                  valueField="id"
                  placeholder="Select item"
                  searchPlaceholder="Search..."
                  value={selectedMedSchems}
                  onChange={this.onselectedMedSchemsChange}
                  selectedStyle={styles.selectedStyle}
                />

                <View>
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorMedicalAid}
                  </Text>
                  {/*<Text>{selectedMedSchems}</Text>*/}
                </View>

                {this.state.showMedNum ? (
                  <View style={styles.action}>
                    <TextInput
                      placeholder={"Medical Aid No."}
                      autoCapitalize="none"
                      value={this.state.cardNumber}
                      onChangeText={(val) =>
                        this.updateInputsVal(val, "cardNumber")
                      }
                      style={styles.text_input}
                    />
                    <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                      {this.state.errorIdNumber}
                    </Text>
                  </View>
                ) : (
                  <View></View>
                )}

                <Text style={styles.text_footer}></Text>
                <View style={styles.action}>
                  <TextInput
                    placeholder={"ID Number"}
                    autoCapitalize="none"
                    value={this.state.idNumber}
                    maxLength={13}
                    keyboardType={"numeric"}
                    numeric
                    onChangeText={(val) =>
                      this.updateInputsVal(val, "idNumber")
                    }
                    style={styles.text_input}
                  />
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorIdNumber}
                  </Text>
                </View>
                <Text style={styles.text_footer}></Text>
                <View style={styles.action}>
                  <TextInput
                    placeholder={"Cellphone"}
                    autoCapitalize="none"
                    value={this.state.cellphone}
                    maxLength={10}
                    keyboardType={"numeric"}
                    numeric
                    onChangeText={(val) =>
                      this.updateInputsVal(val, "cellphone")
                    }
                    style={styles.text_input}
                  />
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorCellphone}
                  </Text>
                </View>
                <Text style={styles.text_footer}></Text>
                <View style={styles.action}>
                  <TextInput
                    placeholder={"Email"}
                    autoCapitalize="none"
                    value={this.state.email}
                    onChangeText={(email) => this.validateEmail(email)}
                    style={styles.text_input}
                  />
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorEmail}
                  </Text>
                </View>

                <View
                  style={{
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 10,
                  }}
                >
                  <TouchableOpacity
                    style={styles.loginBtn}
                    onPress={() => this.UpdateProfile()}
                  >
                    <Text style={styles.loginText}>Update</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 15,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 0,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  textInput: {
    fontSize: 16,
    marginTop: 10,
    borderBottomColor: "#302121",
    marginLeft: 2,
    borderBottomWidth: 1,
    paddingBottom: 0,
    paddingVertical: 0,
    width: "50%",
  },
  textInput2: {
    fontSize: 16,
    marginTop: 25,
    borderBottomColor: "#302121",
    marginLeft: 2,
    borderBottomWidth: 1,
    paddingBottom: 0,
    paddingVertical: 15,
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  texterror: {
    fontSize: 12,
  },
  action: {
    flexDirection: "row",
    marginTop: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#d9d4d9",
    paddingBottom: 0,
  },
  text_input: {
    flex: 1,
    paddingLeft: 10,
    color: "#000",
    fontSize: 16,
  },
  text_footer: {
    fontSize: 18,
    color: "black",
  },

  dropdownButtonStyle: {
    width: 180,
    height: 50,
    backgroundColor: "#FAFAFA",
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#302121",
  },
  dropdownButtonTxtStyle: {
    flex: 1,
    fontSize: 16,
    fontWeight: "normal",
    color: "#151E26",
  },
  dropdownButtonArrowStyle: {
    fontSize: 28,
  },
  dropdownButtonIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },
  dropdownMenuStyle: {
    backgroundColor: "#E9ECEF",
    borderRadius: 8,
  },
  dropdownItemStyle: {
    width: "100%",
    flexDirection: "row",
    paddingHorizontal: 12,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 8,
  },
  dropdownItemTxtStyle: {
    flex: 1,
    fontSize: 16,
    fontWeight: "normal",
    color: "#151E26",
  },
  dropdownItemIconStyle: {
    fontSize: 28,
    marginRight: 8,
  },

  dropdown: {
    height: 50,
    backgroundColor: "transparent",
    borderBottomColor: "gray",
    borderBottomWidth: 0.5,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 14,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
  icon: {
    marginRight: 5,
  },
  selectedStyle: {
    borderRadius: 12,
  },
});
