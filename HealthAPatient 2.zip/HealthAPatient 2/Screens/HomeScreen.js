import React from "react";
import { View, Text } from "react-native";
import { Image } from "expo-image";
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from "@react-navigation/drawer";
import Icon from "react-native-vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import PortalScreen from "./PortalScreen";
import ProfileScreen from "./ProfileScreen";

import { AuthContext } from "./Context";

const Drawer = createDrawerNavigator();

const myDrawer = createDrawerNavigator();

export default function HomeScreen() {
  const { signOut } = React.useContext(AuthContext);
  const [userToken, setUserToken] = React.useState(null);

  const getToken = async () => {
    try {
      let userToken = await AsyncStorage.getItem("userToken");
      setUserToken(userToken);
      //console.log('user token',userToken);
    } catch (error) {
      console.log(error);
    }
  };

  React.useEffect(() => {
    getToken();
  }, []);

  return (
    <myDrawer.Navigator
      drawerPosition="left"
      drawerContent={(props) => {
        return (
          <DrawerContentScrollView {...props}>
            <DrawerItemList {...props} />
            <DrawerItem
              label={() => (
                <Text
                  style={{ color: "#1F3A93", fontSize: 18, fontWeight: "bold" }}
                >
                  Logout
                </Text>
              )}
              onPress={() => {
                signOut();
              }}
            />
          </DrawerContentScrollView>
        );
      }}
      screenOptions={{
        activeTintColor: "#fff",
        activeBackgroundColor: "#fff",
        itemStyle: { marginVertical: 0 },
        headerShown: false,
        drawerStyle: { width: 250, backgroundColor: "#fff" },
        labelStyle: {
          fontFamily: "Roboto",
          color: "#1F3A93",
        },
      }}
    >
      <myDrawer.Screen
        name="Logo"
        component={PortalScreen}
        options={{
          drawerLabel: "",
          drawerIcon: () => {
            return (
              <Image
                source={
                  "https://batcave.healtha.co.za/uploads/assets/HealthA.png"
                }
                style={{
                  height: 160,
                  alignSelf: "center",
                  width: 220,
                  margin: 0,
                }}
              />
            );
          },
        }}
      />
      <myDrawer.Screen
        name="Home"
        component={PortalScreen}
        options={{
          drawerIcon: () => {
            return <Icon name={"home"} color="#1F3A93" size={30} />;
          },
        }}
      />
      <myDrawer.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          drawerIcon: () => {
            return <Icon name={"person"} color="#1F3A93" size={30} />;
          },
        }}
      />
    </myDrawer.Navigator>
  );
}
