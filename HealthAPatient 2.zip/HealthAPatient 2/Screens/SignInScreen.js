import React from "react";
import {
  StyleSheet,
  Dimensions,
  Text,
  TextInput,
  View,
  Button,
  TouchableHighlight,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  ActivityIndicator,
  Alert,
  SafeAreaView,
} from "react-native";
import { Image } from "expo-image";
import FlashMessage, {
  showMessage,
  hideMessage,
} from "react-native-flash-message";

import { AuthContext } from "./Context";

const SignInScreen = ({ navigation }) => {
  const [isFLoading, setFIsloading] = React.useState(false);
  const [isGLoading, setGIsloading] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState("");
  const inputRef = React.useRef(null);

  const [data, setData] = React.useState({
    email: "",
    password: "",
    check_textInputChange: false,
  });

  const handleEmailChange = (val) => {
    setData({
      ...data,
      email: val,
      errorMessage: "",
    });
    setErrorMessage("");
  };

  const handlePasswordChange = (val) => {
    setData({
      ...data,
      password: val,
      errorMessage: "",
    });
    setErrorMessage("");
  };

  const { signIn } = React.useContext(AuthContext);

  const { FBSignIn } = React.useContext(AuthContext);

  const { googleSignIn } = React.useContext(AuthContext);

  const userLogin = (email, password) => {
    if (data.email == "") {
      //this.setState({errorEmail:'Enter email'});
      setErrorMessage("Enter email");
    }
    if (data.password == "") {
      //this.setState({errorPassword:'Enter password'})
      setErrorMessage("Enter password");
    }
    if (data.email != "" && data.password != "") {
      signIn(data.email, data.password);
    }
  };
  const FaceBookSignIn = async () => {
    setFIsloading(true);
    let name = "";
    try {
      await Facebook.initializeAsync({
        appId: "701719260823826",
      });
      const { type, token, expirationDate, permissions, declinedPermissions } =
        await Facebook.logInWithReadPermissionsAsync({
          permissions: ["public_profile", "email"],
        });
      console.log(type);

      /*fetch(`https://graph.facebook.com/me?access_token=${token}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                })
                .catch(e => console.log(e))*/

      if (type === "success") {
        // Get the user's name using Facebook's Graph API
        /*const response = await fetch(`https://graph.facebook.com/me?access_token=${token}`);
                    Alert.alert('Logged in!', `Hi ${(await response.json()).name}!`);*/

        fetch(`https://graph.facebook.com/me?access_token=${token}`)
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            setFIsloading(false);
            name = data.name;
            FBSignIn(token, name);
          })
          .catch((error) => {
            console.log(error);
            setFIsloading(false);
          });
      } else {
        //FBSignIn(token,name);
        // type === 'cancel'
        setFIsloading(false);
      }
    } catch ({ message }) {
      alert(`Facebook Login Error: ${message}`);
      setFIsloading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    const config = {
      expoClientId: `1063852965956-c1q8d7aoj2ep3lmpkprovsrn4pqhlirm.apps.googleusercontent.com`,
      //iosClientId: `329609798579-udavpnfbcki7ljsg4i18m839ikpbpie5.apps.googleusercontent.com`,
      androidClientId: `1063852965956-oovtdfv1cvdf03ct2grdij139bjro6vf.apps.googleusercontent.com`,
      scopes: ["profile", "email"],
      //iosStandaloneAppClientId: `<YOUR_IOS_CLIENT_ID>`,
      androidStandaloneAppClientId: `1063852965956-oovtdfv1cvdf03ct2grdij139bjro6vf.apps.googleusercontent.com`,
    };
    setGIsloading(true);

    Google.logInAsync(config)
      .then((result) => {
        //console.log(result)
        const { type, user } = result;
        if (type === "success") {
          //console.log(result.accessToken);
          setGIsloading(false);
          const { id, email, name, givenName, familyName, photoUrl } = user;
          googleSignIn(result.accessToken, user);

          //navigation.navigate('SignUp');
        } else {
          //return { cancelled: true };
          setGIsloading(false);
          console.log("Google Signin cancelled");
        }
      })
      .catch((error) => {
        setGIsloading(false);
        console.log(error);
      });
  };
  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#1F3A93" />
      <View style={styles.header}>
        <View style={styles.logoView}>
          <Image
            source={"https://batcave.healtha.co.za/uploads/assets/HealthA.png"}
            style={styles.logo}
          />
        </View>
      </View>
      <View style={styles.footer}>
        <Text style={styles.text_footer}>Email</Text>
        <View style={styles.action}>
          <TextInput
            placeholder={"Your Email"}
            autoCapitalize="none"
            value={data.email}
            onChangeText={(val) => handleEmailChange(val)}
            style={styles.text_input}
          />

          <Text></Text>
        </View>
        <Text style={[styles.text_footer, { marginTop: 20 }]}>Password</Text>
        <View style={styles.action}>
          <TextInput
            placeholder={"Your Password"}
            autoCapitalize="none"
            value={data.password}
            onChangeText={(val) => handlePasswordChange(val)}
            secureTextEntry={true}
            style={styles.text_input}
          />
        </View>
        <Text style={[styles.texterror, { color: "#1F3A93" }]}>
          {errorMessage}
        </Text>
        <View style={styles.textSignIn}>
          <TouchableOpacity
            onPress={() => {
              userLogin(data.email, data.password);
            }}
            style={[
              styles.signIn,
              {
                borderColor: "#1F3A93",
                borderWidth: 1,
                marginTop: 20,
                backgroundColor: "#1F3A93",
              },
            ]}
          >
            <Text style={[styles.textSign, { color: "#fff" }]}>Sign In</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.textSignIn}>
          <TouchableOpacity
            style={styles.signIn}
            onPress={() => navigation.navigate("Reset")}
          >
            <Text style={[styles.textForgotPass, { color: "#1F3A93" }]}>
              Forgot Password
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.signUpSocials}>
          <TouchableOpacity
            onPress={() => FaceBookSignIn()}
            style={{ marginLeft: 5 }}
          >
            {isFLoading ? (
              <View>
                <ActivityIndicator size="large" color="#1F3A93" />
              </View>
            ) : (
              <View>
                <Image
                  style={{ width: 40, height: 40, borderRadius: 15 }}
                  source={
                    "https://batcave.healtha.co.za/uploads/assets/facebook-icon.png"
                  }
                />
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleGoogleSignIn()}
            style={{ marginLeft: 5 }}
          >
            {isGLoading ? (
              <View>
                <ActivityIndicator size="large" color="#1F3A93" />
              </View>
            ) : (
              <View>
                <Image
                  style={{ width: 40, height: 40, borderRadius: 15 }}
                  source={
                    "https://batcave.healtha.co.za/uploads/assets/7611770.png"
                  }
                />
              </View>
            )}
          </TouchableOpacity>
          {/* <TouchableOpacity style={{marginLeft:5}}><Image style={{width:40,height:40, borderRadius:15}} source={require('../assets/linkedin-logo.png')} resizeMode="cover"/></TouchableOpacity> */}
        </View>
        <View style={styles.signUp}>
          <Text
            style={[
              styles.textForgotPass,
              { color: "#302121" },
              { marginTop: 20 },
            ]}
          >
            Don't have Account?{" "}
          </Text>
          <TouchableOpacity
            onPress={() => navigation.navigate("SignUp")}
            style={[
              styles.signUpButton,
              {
                borderColor: "#1F3A93",
                borderWidth: 1,
                marginTop: 25,
                backgroundColor: "#1F3A93",
                marginLeft: 5,
              },
            ]}
          >
            <Text style={[styles.textSignUp, { color: "#fff" }]}>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </View>
      <FlashMessage inputRef="myLocalFlashMessage" position="bottom" />
    </View>
  );
};

export default SignInScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1F3A93",
  },
  header: {
    flex: 2,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingHorizontal: 20,
    paddingBottom: 0,
  },
  footer: {
    flex: 3,
    backgroundColor: "#fff",
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    paddingVertical: 0,
    paddingHorizontal: 30,
  },
  text_header: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 30,
  },
  text_footer: {
    fontSize: 18,
    color: "black",
  },
  action: {
    flexDirection: "row",
    marginTop: 5,
    borderBottomWidth: 1,
    borderBottomColor: "#000",
    paddingBottom: 5,
  },
  text_input: {
    flex: 1,
    paddingLeft: 10,
    color: "#000",
    fontSize: 16,
  },
  title: {
    color: "#561b6e",
    fontWeight: "bold",
    fontSize: 25,
  },
  text: {
    color: "black",
    marginTop: 5,
  },
  button: {
    alignItems: "center",
    marginTop: 50,
  },
  signIn: {
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  signUpButton: {
    height: 30,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  signUp: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  signUpSocials: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold",
    paddingHorizontal: 10,
  },
  textSignUp: {
    fontSize: 16,
    fontWeight: "bold",
    paddingHorizontal: 10,
  },
  textForgotPass: {
    fontSize: 12,
  },
  texterror: {
    fontSize: 12,
  },
  logo: {
    height: 115,
    width: 115,
    margin: 5,
  },
  logoView: {
    backgroundColor: "#f7f7f7",
    borderWidth: 1,
    borderColor: "#f7f7f7",
    borderRadius: 100,
    position: "absolute",
  },
});
