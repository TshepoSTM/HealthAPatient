import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  StatusBar,
  TouchableHighlight,
  SafeAreaView,
  FlatList,
  Alert,
  RadioButton,
  TextInput,
  ImageBackground,
} from "react-native";
import Dialog, {
  DialogTitle,
  DialogContent,
  DialogFooter,
  DialogButton,
  SlideAnimation,
  ScaleAnimation,
} from "react-native-popup-dialog";
import Icon from "react-native-vector-icons/Ionicons";
import { url_key, myApiKey } from "../config/url_key";
import axios from "axios";

export default class ForgotPassScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      cart_data: [],
      email: this.props.route.params.email,
      password: "",
      confpassword: "",
      code: "",
      isLoading: false,
      errorMessage: "",
      errorEmail: "",
      errorPassword: "",
      errorConfpassword: "",
      errorCode: "",
      cust_id_fk: "",
      check: "",
      showPassPanel: true,
      showDialog: false,
    };
  }

  updateInputsVal = (val, prop) => {
    const state = this.state;
    state[prop] = val;
    this.setState(state);
    this.setState({ errorEmail: "" });
    this.setState({ errorPassword: "" });
    this.setState({ errorConfpassword: "" });
    this.setState({ errorCode: "" });
    this.setState({ errorMessage: "" });
  };

  onDialogDismis() {
    this.setState({ showDialog: false });
  }

  resetPassword() {
    if (this.state.email == "") {
      this.setState({ errorEmail: "Enter email" });
    }
    if (this.state.password == "") {
      this.setState({ errorPassword: "Enter password" });
    }
    if (this.state.confpassword == "") {
      this.setState({ errorConfpassword: "Enter confirm password" });
    }
    if (this.state.confpassword != this.state.password) {
      this.setState({ errorConfpassword: "Password does not match" });
      return;
    }

    if (this.state.email != "" && this.state.password != "") {
      var param = {
        email: this.state.email,
        password: this.state.password,
        repeat_pswrd: this.state.confpassword,
      };

      var data = { name: "insertpass", param: param };
      console.log(data);

      axios({
        url: url_key + "insertpass",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);
            if (response.data.error) {
              this.setState({ errorMessage: response.data.error.message });

              console.warn(response.data.error.message);
            } else {
              if (response.data == true) {
                //this.setState({errorMessage:'New password created successfully'})
                this.setState({ showDialog: true });
                setTimeout(() => {
                  this.setState({ showDialog: false });
                  this.props.navigation.navigate("SignIn");
                }, 5000);
              }
              console.log(response.data);
            }
          },
          (error) => {
            console.log(error);
          }
        )
        .catch((error) => {
          console.log(error);
        });
    }
  }

  sendVerificationCode() {
    if (this.state.code == "") {
      this.setState({ errorCode: "Enter verification code" });
    }

    if (this.state.code != "") {
      var param = { email: this.state.email, ver_code: this.state.code };

      var data = { name: "verifyCode", param: param };
      console.log(data);

      axios({
        url: url_key + "verifyCode",
        method: "POST",
        data: data,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(
          (response) => {
            console.log(response.data);

            if (response.data.error) {
              this.setState({ errorMessage: "Invalid verification code" });

              console.warn(response.data.error.message);
            } else {
              console.log(response.data);
              if (response.data == true) {
                //this.setState({errorMessage:response.data.response.message})
                setTimeout(() => {
                  this.setState({ showPassPanel: false });
                  this.setState({ errorMessage: "" });
                }, 2000);
              } else {
                this.setState({ errorMessage: "Invalid verification code" });
              }
            }
          },
          (error) => {
            console.log(error);
          }
        )
        .catch((error) => {
          console.log(error);
        });
    }
  }

  render() {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar backgroundColor="#1F3A93" />
        <View style={styles.topBar}>
          <View style={{ width: "10%" }}>
            <TouchableOpacity></TouchableOpacity>
          </View>
          <View style={{ width: "80%", alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                alignSelf: "center",
              }}
            ></View>
          </View>
          <View style={{ width: "10%" }}>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("SignIn")}
            >
              <Icon name={"close"} color="#1F3A93" size={30} />
            </TouchableOpacity>
          </View>
        </View>

        <View>
          <View style={styles.bodyHeader}></View>
          <View style={styles.bodyContainer}>
            <Text
              style={{ fontSize: 22, fontWeight: "bold", color: "#1F3A93" }}
            >
              Reset Your Password
            </Text>
            <Text style={{ fontSize: 16, color: "#000", marginTop: 20 }}>
              Here you can easily retrieve/create a new password.
            </Text>

            <Dialog
              visible={this.state.showDialog}
              dialogAnimation={
                new SlideAnimation({
                  slideFrom: "bottom",
                })
              }
              onTouchOutside={() => this.onDialogDismis()}
              onHardwareBackPress={() => this.onDialogDismis()}
              dialogTitle={
                <DialogTitle
                  title="Congradulations"
                  style={{
                    backgroundColor: "#F7F7F8",
                  }}
                  hasTitleBar={false}
                  align="center"
                />
              }
              footer={
                <DialogFooter>
                  <DialogButton
                    text="OK"
                    bordered
                    onPress={() => this.onDialogDismis()}
                    key="button-1"
                  />
                </DialogFooter>
              }
            >
              <DialogContent
                style={{ alignItems: "center", justifyContent: "center" }}
              >
                <Icon name={"checkmark-circle"} color={"green"} size={50} />
                <Text>New password created successfully</Text>
              </DialogContent>
            </Dialog>
            {/*
                            <TextInput style={styles.textInput} placeholder="Username" 
                            autoCapitalize="none"
                            value={this.state.email}
                            onChangeText={(val) => this.updateInputsVal(val, 'email')}/>
                            <Text style={[styles.texterror,{color:'#1F3A93'}]}>{this.state.errorEmail}</Text>
                        
                        */}

            <View>
              {this.state.showPassPanel ? (
                <View>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Verification code"
                    value={this.state.code}
                    onChangeText={(val) => this.updateInputsVal(val, "code")}
                  />
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorCode}
                  </Text>
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorMessage}
                  </Text>
                  <View
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 15,
                    }}
                  >
                    <TouchableOpacity
                      style={styles.loginBtn}
                      onPress={() => this.sendVerificationCode()}
                    >
                      <Text style={styles.loginText}>Verify Code</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <View>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Password"
                    autoCapitalize="none"
                    value={this.state.password}
                    onChangeText={(val) =>
                      this.updateInputsVal(val, "password")
                    }
                    secureTextEntry={true}
                  />
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorPassword}
                  </Text>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Confirm Password"
                    autoCapitalize="none"
                    value={this.state.confpassword}
                    onChangeText={(val) =>
                      this.updateInputsVal(val, "confpassword")
                    }
                    secureTextEntry={true}
                  />
                  <Text style={[styles.texterror, { color: "#1F3A93" }]}>
                    {this.state.errorConfpassword}
                  </Text>
                  <Text style={[styles.texterror, { color: "#ff3c00" }]}>
                    {this.state.errorMessage}
                  </Text>
                  <View
                    style={{
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 15,
                    }}
                  >
                    <TouchableOpacity
                      style={styles.loginBtn}
                      onPress={() => this.resetPassword()}
                    >
                      <Text style={styles.loginText}>Reset</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 25,
    marginHorizontal: 10,
  },
  bodyHeader: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  bodyContainer: {
    paddingHorizontal: 15,
    paddingVertical: 5,
    marginTop: 5,
  },
  textInput: {
    fontSize: 16,
    marginTop: 20,
    borderBottomColor: "#302121",
    marginLeft: 2,
    borderBottomWidth: 1,
    paddingBottom: 0,
    paddingVertical: 15,
  },
  loginBtn: {
    width: 100,
    backgroundColor: "#1F3A93",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    marginTop: 20,
  },
  loginText: {
    color: "#fff",
    fontSize: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  texterror: {
    fontSize: 12,
  },
});
