import { View, Text } from "react-native";
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import SignInScreen from "../Screens/SignInScreen";
import SignUpScreen from "../Screens/SignUpScreen";
import ResetPassScreen from "../Screens/ResetPassScreen";
import ForgotPassScreen from "../Screens/ForgotPassScreen";

const myStarterStack = createNativeStackNavigator();

const screenOptionStyle = {
  headerShown: false,
};

export default function StarterStackScreen() {
  return (
    <myStarterStack.Navigator screenOptions={screenOptionStyle}>
      <myStarterStack.Screen name={"SignIn"} component={SignInScreen} />
      <myStarterStack.Screen name={"SignUp"} component={SignUpScreen} />
      <myStarterStack.Screen name={"Reset"} component={ResetPassScreen} />
      <myStarterStack.Screen name={"Forgot"} component={ForgotPassScreen} />
    </myStarterStack.Navigator>
  );
}
