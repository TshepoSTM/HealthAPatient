import { View, Text } from "react-native";
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import HomeScreen from "../Screens/HomeScreen";
import ProfileScreen from "../Screens/ProfileScreen";
//import PortalScreen from "../Screens/PortalScreen";
import HistoryScreen from "../Screens/HistoryScreen";
import ChatScreen from "../Screens/ChatScreen";
import MyConsultationScreen from "../Screens/MyConsultationScreen";
import ConsultationScreen from "../Screens/ConsultationScreen";
import HCPScreen from "../Screens/HCPScreen";
import MapScreen from "../Screens/MapsScreen";
import InvoiceScreen from "../Screens/InvoiceScreen";
import MyInvoiceScreen from "../Screens/MyInvoiceScreen";

const myRootStack = createNativeStackNavigator();

const screenOptionStyle = {
  headerShown: false,
};

export default function RootStackScreen() {
  return (
    <myRootStack.Navigator screenOptions={screenOptionStyle}>
      <myRootStack.Screen name={"Home"} component={HomeScreen} />
      <myRootStack.Screen name={"Profile"} component={ProfileScreen} />
      <myRootStack.Screen name={"History"} component={HistoryScreen} />
      <myRootStack.Screen name={"Chat"} component={ChatScreen} />
      <myRootStack.Screen
        name={"MyConsultation"}
        component={MyConsultationScreen}
      />
      <myRootStack.Screen
        name={"Consultation"}
        component={ConsultationScreen}
      />
      <myRootStack.Screen name={"HCP"} component={HCPScreen} />
      <myRootStack.Screen name={"Map"} component={MapScreen} />
      <myRootStack.Screen name={"Invoice"} component={InvoiceScreen} />
      <myRootStack.Screen name={"MyInvoices"} component={MyInvoiceScreen} />
    </myRootStack.Navigator>
  );
}
